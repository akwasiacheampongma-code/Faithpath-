# Audit und Plan — V4 F

Das vor Änderungen erstellte Audit steht in [docs/AUDIT.md](docs/AUDIT.md), der priorisierte Produktplan in [docs/PRODUCT_PLAN.md](docs/PRODUCT_PLAN.md).

Die früheren QA-Behauptungen des Ausgangsprojekts wurden nicht als Nachweis übernommen. Aktuelle Testergebnisse stehen in [QA_REPORT.md](QA_REPORT.md), Grenzen in [KNOWN_ISSUES.md](KNOWN_ISSUES.md).
