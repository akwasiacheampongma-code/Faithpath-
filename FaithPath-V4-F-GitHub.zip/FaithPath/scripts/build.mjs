import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { auditContent } from "./validate-content.mjs";
import { BUILD } from "../src/version.js";
const { index, report } = auditContent();
if (report.errors.length) throw new Error(report.errors.join("\n"));
fs.writeFileSync("data/reference-index.json", JSON.stringify(index));
fs.writeFileSync("data/content-report.json", JSON.stringify(report, null, 2));
const out = "dist",
  release = `releases/${BUILD}`;
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(`${out}/${release}/data`, { recursive: true });
for (const folder of ["trees", "icons", "data/bibles"])
  fs.cpSync(folder, `${out}/${folder}`, { recursive: true });
fs.cpSync("src", `${out}/${release}/src`, { recursive: true });
fs.copyFileSync("styles.css", `${out}/${release}/styles.css`);
for (const file of [
  "index.json",
  "stories.json",
  "reference-index.json",
  "content-report.json",
])
  fs.copyFileSync("data/" + file, `${out}/${release}/data/${file}`);
for (const f of ["manifest.webmanifest", "_headers", "_redirects", "404.html"])
  fs.copyFileSync(f, `${out}/${f}`);
const html = fs
  .readFileSync("index.html", "utf8")
  .replace("./styles.css", `./${release}/styles.css`)
  .replace("./app.js", `./${release}/src/app.js`);
fs.writeFileSync(`${out}/index.html`, html);
fs.writeFileSync(
  `${out}/BUILD.txt`,
  `FaithPath V4\n${BUILD}\nSource branch: develop/v4-product-20260916\n`,
);
function files(dir) {
  return fs
    .readdirSync(dir, { withFileTypes: true })
    .flatMap((x) =>
      x.isDirectory()
        ? files(path.join(dir, x.name))
        : [path.join(dir, x.name)],
    );
}
const assets = files(out)
  .filter((f) => !f.endsWith("_headers") && !f.endsWith("_redirects"))
  .map((f) => "./" + f.slice(out.length + 1).replaceAll("\\", "/"))
  .sort();
const template = fs
  .readFileSync("scripts/sw-template.js", "utf8")
  .replace("__BUILD__", BUILD)
  .replace("__ASSETS__", JSON.stringify(assets));
fs.writeFileSync(`${out}/sw.js`, template);
const hashes = Object.fromEntries(
  files(out)
    .sort()
    .map((f) => [
      f.slice(out.length + 1),
      crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex"),
    ]),
);
fs.writeFileSync(
  `${out}/release-integrity.json`,
  JSON.stringify({ build: BUILD, files: hashes }, null, 2),
);
console.log(
  `${BUILD}: ${Object.keys(hashes).length} deployable files, ${report.questions} questions preserved. Publish: dist/`,
);
