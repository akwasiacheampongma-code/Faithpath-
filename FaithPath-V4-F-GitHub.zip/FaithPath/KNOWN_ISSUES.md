# Bekannte Einschränkungen — V4 F

Stand 17.09.2026. Das ist ein getesteter Release-Kandidat, keine uneingeschränkte kommerzielle Freigabe.

1. **Echtes iPhone/Safari und VoiceOver:** Die mobile Browserdarstellung ist in Chromium geprüft. Installation auf dem Home-Bildschirm, iOS-Speicherbereinigung, Safari-Updates, Bildschirmtastatur und VoiceOver benötigen einen Test auf einem tatsächlichen Gerät. Automatisierte axe-Prüfungen ersetzen ihn nicht.
2. **Live-Deployment:** Das fertige Publish-Verzeichnis ist vorhanden. Netlify-Dokumentation und Konfiguration wurden geprüft; ein tatsächlicher Production Deploy samt CDN-Headern und Domainwechsel wurde nicht ausgeführt.
3. **Redaktion:** 1.300 vorhandene textbasiert erzeugte Quizfragen brauchen eine redaktionelle Qualitätsprüfung; bei weiteren 160 fehlt ein Prüfvermerk. Die 100 als geprüft markierten Fragen tragen einen übernommenen Vermerk. Referenzen sind technisch geprüft, keine neue theologische Vollprüfung behauptet.
4. **Contentumfang:** Beide Bibeln sind vollständig. Die 312 Story-/Kapiteleinheiten stammen aus 27 NT-Büchern; ein redaktioneller Storykatalog für das ganze AT fehlt. Vorhandene 4 Pläne und 3 Einsteigerführungen sind erhalten; nicht jedes der gewünschten Beispielthemen hat bereits einen eigenen geführten Weg.
5. **Lokale Speicherung:** Browser- und Gerätespeicher sind begrenzt und können gelöscht werden. Es gibt keinen Kontozugang, keine Synchronisierung und keine zusätzliche Verschlüsselung. Backups müssen bewusst gesichert werden. Gleichzeitig schreibende Tabs werden vor Überschreiben geschützt, aber nicht automatisch zusammengeführt.
6. **Erinnerungen und Baum:** Erinnerungen erscheinen innerhalb der geöffneten App. Keine Push-Nachrichten; sieben statische Baumstufen, keine erfundene Zuordnung einzelner Äste.
7. **GitHub:** Lokale Sicherungs- und Entwicklungsbranches plus History-Bundle vorhanden. Remote-Schreibrecht fehlte; kein Push, keine PR und kein verbundenes Continuous Deployment.
8. **Rollback:** Ein Build-E-Rollback gegen bereits migrierte Daten kann neue Felder verlieren. Vor einem Rückwechsel Export sichern und bei Bedarf den unveränderten Schema-4-Originalstand verwenden.

Für einen kleinen begleiteten, geschlossenen Pilottest ist der Build geeignet. Einen öffentlichen Bezahltest würde ich erst nach dem Gerätetest, einem echten Netlify-Deploy und einer bewussten redaktionellen Freigabe empfehlen. Ein Bezahlsystem war nicht Teil dieses Builds; ein kleiner Test kann organisatorisch außerhalb der App abgewickelt werden.
