# FaithPath V4

**Deine persönliche Glaubensgeschichte.** Build `FP4-20260916-F`, Release-Kandidat vom 17. September 2026.

FaithPath verbindet Situationen und Bibeltexte mit Gedanken, persönlichen Wegen und kleinen Schritten. Später bringt die App frühere Gedanken zurück und fragt: „Was ist daraus geworden?“ Nur die selbst bestätigte Entwicklung verändert den Olivenbaum.

## Starten

Node.js 22 wird für Netlify festgelegt; lokal funktioniert Node.js ab 20. Kein Framework und keine externen Laufzeitbibliotheken.

```sh
npm ci
npm test
npm run build
npm run serve
```

Danach `http://localhost:4174` öffnen. Für die PWA HTTP auf localhost oder HTTPS verwenden; `index.html` nicht per Doppelklick über `file://` starten. Der Entwicklungs-Service-Worker im Quellordner speichert absichtlich nichts. Offline immer mit dem erzeugten `dist/` testen.

## Netlify

- **Manueller Deploy:** `FaithPath-V4-F-Netlify.zip` entpacken und den enthaltenen Ordner mit `index.html`, `sw.js`, `_headers` und `releases/` bei Netlify hochladen. Diese Dateien liegen direkt in der ZIP-Wurzel.
- **Git → Netlify:** Basisverzeichnis leer / Repository-Wurzel, Build `npm run build`, Publish `dist`. `netlify.toml` enthält diese Werte.
- Die App wird unter der **Wurzel einer Domain** betrieben. `<base href="/">` hält Assets auch nach einem Reload tiefer URLs erreichbar. Eine Installation unter `/unterordner/` ist nicht eingerichtet.
- Assets, Content und JavaScript eines Releases liegen unter `releases/BUILD-ID/`. Neue Produktionsversionen bekommen eine neue Kennung in `src/version.js`. Eine bereits veröffentlichte Kennung niemals wiederverwenden.
- Das ZIP wurde lokal gestartet und geprüft. Es wurde **kein Production Deploy** ausgeführt; ein tatsächlicher Netlify-Account-/Domain-Test bleibt offen.

Netlify-Dokumentation: [Build-Konfiguration](https://docs.netlify.com/build/configure-builds/file-based-configuration/), [Headers](https://docs.netlify.com/manage/routing/headers/), [SPA-Rewrites](https://docs.netlify.com/manage/routing/redirects/rewrites-proxies/), [Deploys](https://docs.netlify.com/deploy/create-deploys/).

## Bestehende Daten

Beim ersten Start migriert die App das bisherige Schema verlustarm zu Schema 5. Vorher wird der exakte bisherige Speichertext lokal gesichert. Beschädigte oder unbekannt neuere Daten werden nicht überschrieben. Unbekannte Felder und lange Texte bleiben erhalten. Planfortschritt aus dem bisherigen separaten Key wird übernommen.

**Updates auf derselben Domain veröffentlichen.** Browserdaten gehören zur jeweiligen Origin. Ein Domainwechsel übernimmt sie nicht automatisch; dafür vorher unter „Mehr“ ein Backup exportieren und auf der neuen Domain importieren. Ein alter Build E darf nach der Schema-5-Migration nicht wieder gegen dieselben Daten geöffnet werden, weil sein alter Normalisierer neue Felder nicht kennt. Für einen vollständigen Rückwechsel erst sichern und den früheren Schema-4-Stand wiederherstellen.

Details und alle Keys: [Datenmodell](docs/DATA_MODEL.md). Keine Speicherung auf einem FaithPath-Server. Lokale Texte und JSON-Backups sind nicht zusätzlich verschlüsselt; Browserdaten können vom Betriebssystem oder durch Löschen verloren gehen. Regelmäßige Exporte bleiben sinnvoll.

## Offline und Updates

Die Erstinstallation lädt beide vollständigen Bibeln und die App. Unter „Mehr“ steht **offline bereit**, sobald die Dateien vollständig geladen sind und der aktive Service Worker die Seite kontrolliert. Bis dahin online bleiben. Die Anzeige ist kein Versprechen gegen eine spätere Speicherbereinigung durch den Browser.

Eine neue Version wartet auf „Jetzt aktualisieren“. Ein offener Schreibdialog wird nicht automatisch neu geladen. Entwürfe überstehen den getesteten Updateablauf. Fehlerhafte oder unvollständige Downloads ersetzen den funktionierenden Cache nicht. Fremde App-Caches werden nicht gelöscht. Erinnerungen erscheinen beim Öffnen der App; es gibt keine Push-Nachrichten.

## Struktur und Tests

- `src/store.js`: Validierung, Migration, atomare Schreibvorgänge und Wiederherstellung.
- `src/domain.js`: Erinnerungslücken, Verknüpfungen, Chronologie und Baumdarstellung.
- `src/content.js`: erhaltene Situationen, Führungen und Kategorien.
- `src/app.js` / `styles.css`: Navigation, zugängliche Formulare und Ansichten.
- `scripts/validate-content.mjs`: alle Referenzen gegen die tatsächlichen Bibeldaten prüfen.
- `scripts/build.mjs`: eigenständiges Netlify-Release, Cache-Version und SHA-256-Dateiliste.
- `tests/fixtures/baseline-e.json`: aus Commit `3c5b221` erstellte Vergleichsprüfsummen für Inhalte und Assets.

Browserprüfung nach Installation der Entwicklungsabhängigkeiten:

```sh
npx playwright install chromium
npm run test:browser
npm run test:update
```

Der Test des echten Updates von E benötigt die Git-Historie mit Commit `3c5b221ac958775588a62b49fbc9df5e82eed482`. Im Projektpaket liegt dafür `FaithPath-history.bundle`. Beispiel für einen vollständigen Checkout: `git clone FaithPath-history.bundle FaithPath`. Falls ein eigener Chromium-Pfad nötig ist: `FAITHPATH_CHROMIUM=/pfad/zu/chromium`. Ergebnisse und Screenshots entstehen unter `qa-output/`.

Die GitHub-QA-Konfiguration ist vorbereitet. Der verwendete Connector verweigerte Branch-Schreibzugriffe mit HTTP 403; Shell-Push hatte keine Anmeldung. Deshalb wurden Sicherung und Entwicklung **nur lokal** versioniert. `main` und `develop/v4` auf GitHub wurden nicht überschrieben. Für Continuous Deployment einmalig Schreibzugriff freigeben und den Entwicklungsbranch verbinden.

## Release-Unterlagen

[Änderungen](CHANGELOG.md) · [QA](QA_REPORT.md) · [bekannte Einschränkungen](KNOWN_ISSUES.md) · [Contentstatus](CONTENT_STATUS.md) · [Featurevergleich](docs/REGRESSION.md) · [Audit](docs/AUDIT.md) · [Produktplan](docs/PRODUCT_PLAN.md) · [Research](PRODUCT_RESEARCH.md).
