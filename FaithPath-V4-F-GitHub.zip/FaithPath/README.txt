FaithPath V4 — FP4-20260916-F
Deine persönliche Glaubensgeschichte.

NETLIFY: Das fertige Publish-Verzeichnis ist dist/.
Im Netlify-ZIP liegen index.html und sw.js direkt an der Wurzel.
Für Git-Builds: npm run build, Publish dist, Node 22.

Bitte README.md, QA_REPORT.md und KNOWN_ISSUES.md lesen.
Keine Browserdaten löschen, um ein Update zu erzwingen.
Unter Mehr regelmäßig Backup exportieren.
