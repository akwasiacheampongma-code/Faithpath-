# FaithPath: USP und Vorgaben für den nächsten Build

Stand: 17. September 2026. Vom Nutzer beauftragt: Wettbewerbsvergleich durchführen und die daraus geschärfte Positionierung für den nächsten FaithPath-Build festhalten. Dieses Dokument ist eine Produktvorgabe; es behauptet keine bereits umgesetzten neuen Funktionen. Ausgangsbuild bleibt FP4-20260916-F.

## Ergebnis des Wettbewerbsvergleichs

Methode: gezielte Recherche offizieller Produktseiten von sechs Angeboten. Die Aussagen unten beschreiben vom Anbieter beworbene Funktionen. Keine vollständigen angemeldeten Praxistests, keine Markt-Vollständigkeit, keine verifizierten Nutzungs-/Umsatzzahlen. Eine auf einer Seite nicht beschriebene Funktion gilt nicht automatisch als fehlend.

| Angebot | Auf der offiziellen Seite beschrieben | Konsequenz für FaithPath |
| --- | --- | --- |
| [YouVersion](https://www.youversion.com/) | Bibellesen, Pläne, Gebete, Markierungen und Notizen | Diese Werkzeuge allein begründen keine eigenständige Positionierung. |
| [Day One](https://dayoneapp.com/features/) | Frühere Einträge über „On This Day“, Suche, Tags und Journaling-Erinnerungen | Das bloße Wiederanzeigen alter Texte ist kein einzigartiges Merkmal. |
| [Echo Prayer](https://www.echoprayer.com/) | Gebetslisten, Erinnerungen für konkrete Anliegen und Kennzeichnung beantworteter Gebete | Auch die spätere Beschäftigung mit einem früheren Anliegen existiert bereits. |
| [HolyJot](https://www.holyjot.com/christian-journaling-app) | Mit Bibelstellen verknüpfte Journaleinträge, angeleitete Pläne und optionale KI-Reflexionsfragen | „Bibel + Journal + Pläne“ ist ebenfalls besetzt. |
| [Pastures](https://www.pastures.app/) | Gebete, Predigtnotizen und Journal; Timeline, persönliche Journeys und Suche; Bibel und Lesepläne | Besonders nah an „persönliche Glaubensgeschichte“. Die Formulierung allein trägt keinen exklusiven USP. |
| [Psalmlog](https://psalmlog.com/) | Eigene Alltagssituation, zugeordneter Bibeltext, Reflexion und ein konkreter Schritt; gespeicherter Verlauf, auf den man zurückblicken kann | Auch „Lesen in Handeln verwandeln“ ist bereits ein beworbenes Produktversprechen. |

Bewertung: Der bisherige Kern bleibt sinnvoll, aber weltweite Einzigartigkeit ist nicht belegt. Eine glaubwürdige Differenzierung muss aus dem Schwerpunkt, der konkreten Ausführung und der Haltung entstehen. Es gibt keine Grundlage für „erste/einzige App“ oder die Behauptung, Konkurrenten könnten keine Rückblicke.

## Geschärfte Positionierung

Marke: **FaithPath – deine persönliche Glaubensgeschichte.**

Leitfrage: **Was ist aus dem geworden, was dich bewegt hat?**

USP-Arbeitsfassung:

> FaithPath greift frühere Glaubensgedanken und persönliche Vorhaben wieder auf. Es verbindet den damaligen Bibeltext, deinen Gedanken und deinen kleinen Schritt mit deinem heutigen Rückblick – damit du selbst erkennst, was daraus geworden ist.

Kurze Erklärung:

> Halte fest, was dich bewegt. Geh einen kleinen Schritt. Begegne deinem Gedanken später wieder und halte fest, wie du ihn heute siehst.

Grundhaltung bleibt unverändert:

> FaithPath misst nicht deinen Glauben. FaithPath hilft dir, deine Entwicklung zu erkennen.

Die besondere Produktleistung, die wir ausbauen und prüfen wollen: **offene persönliche Gedanken gezielt wieder aufgreifen und ihre Fortsetzung dokumentieren.** Ein Jahrestag, eine allgemeine Schreibaufforderung oder ein Aktivitätszähler allein erfüllt diese Vorgabe nicht. Das ist die eigene Positionierungsentscheidung aus der Recherche, kein Beweis, dass andere Produkte dies nicht anbieten.

## Wichtigster Ausbau: „Damals & heute“

„Erinnerungslücken“ bleibt höchstens ein interner Begriff. Gegenüber Nutzern bevorzugt „Damals & heute“, „Wieder aufgreifen“ und „Zurückblicken“. Kein Vorwurf, etwas vergessen oder zu wenig getan zu haben.

Beispiel mit ausdrücklich fiktiven Daten:

**Damals · 12. Januar**
„Ich möchte in Streitgesprächen zuerst zuhören.“
Verbunden mit Jakobus 1,19 und dem persönlichen Weg „Geduld“.
Mein kleiner Schritt: „Im nächsten Gespräch ausreden lassen.“

**Heute**
„Wie ist es dir damit gegangen?“
Der Nutzer kann Veränderung beschreiben, Weiterarbeiten oder unveränderte Lage festhalten, einen freien Gedanken hinzufügen oder später wieder hinsehen.

Nach dem Speichern stehen Ursprung und Antwort sichtbar zusammen. Spätere Rückblicke ergänzen diese Geschichte, ohne frühere Antworten umzuschreiben. „Es bleibt schwierig“ ist ein vollwertiger Eintrag. Nur eine ausdrücklich selbst bestätigte Entwicklung zählt für den Baum.

## Priorität für den nächsten Build

### MUSS

1. Vor Implementierung dieses Dokument und die ursprünglichen Produktregeln lesen. Den aktuellen Code und gegebenenfalls neuere Nutzeränderungen prüfen; nicht blind vom archivierten Build ausgehen.
2. In einem Rückblick den konkreten ursprünglichen Gedanken, dessen Datum, die verbundene Stelle und den damaligen Schritt zeigen, soweit wirklich vorhanden. Kein fehlendes Datum, Zitat oder Zusammenhang darf erfunden werden.
3. Ursprung und spätere Antwort direkt miteinander verknüpfen; vom Rückblick zum Original und vom Original zu seinen Rückblicken navigieren können. Bestehende Pfad- und Quellen-IDs nutzen. Neue Felder nur additiv und mit Migration/Backup-Test.
4. Persönliche Wege als zusammenhängende Geschichte darstellen. Doppelte Spiegel zwischen Journal, Reflexion und Meilenstein nicht mehrfach als Entwicklung zählen.
5. Erinnerungen anhand tatsächlicher Aktivität und gewählter Erinnerungstermine prüfen. Jüngere Reflexionen, Rückblicke, Snoozes und „Im Moment nicht“ berücksichtigen. Keine behauptete intelligente oder spirituelle Deutung.
6. Ruhige Hauptaktion, maximal eine hervorgehobene Einladung auf Heute. Direkter Bibelzugriff bleibt erhalten. Kein zusätzlicher Hauptbereich für dieselbe Funktion.
7. Website-/Onboardingtexte auf die Leitfrage ausrichten. Nicht nur die Startseitenüberschrift austauschen: Der tatsächliche Rückblickablauf muss das Versprechen erfüllen.
8. Offline-first und lokale Speicherung bewahren. Keine Cloudpflicht, keine Glaubenspunkte, keine Streaks, keine KI-Autorität. „Privat“ nicht mit zusätzlicher Verschlüsselung verwechseln; der bisherige lokale Stand ist nicht zusätzlich verschlüsselt.

### SOLLTE

- Nach einer ersten Reflexion eine freiwillige spätere Wiedervorlage anbieten, ohne den Nutzer zum Weg oder Schritt zu zwingen.
- Nach einem Rückblick zeigen: „Dieser Gedanke gehört jetzt zu deiner Geschichte.“ Keine automatische Erfolgsmeldung bei unveränderter Lage.
- Wege mit mehreren Rückblicken auf kleinen iPhone-Displays gut lesbar machen, Original und spätere Antwort eindeutig beschriften.
- Eine klar gekennzeichnete, freiwillige Beispieldarstellung des Effekts erwägen. Nie fiktive Entwicklung als echten Nutzerstand speichern. Kein vorgetäuschtes altes Ereignis im Onboarding.

### SPÄTER / NICHT JETZT

Kein KI-Chat, kein sozialer Feed, keine Rankings, keine zusätzliche Inhaltsmenge als Ersatz für den Kern. Keine Ast-Interaktivität, solange die Baumassets diese Beziehung nicht tatsächlich abbilden. Push bleibt ein eigener späterer Entscheid; derzeit erscheinen Einladungen beim Öffnen der App.

## Abnahme für den nächsten Build

- Ein Nutzer versteht anhand eines konkreten Beispiels, weshalb er später zurückkehren könnte.
- Ein echter gespeicherter Gedanke führt zu einem Rückblick; Ursprung, Weg und spätere Antwort bleiben gemeinsam auffindbar.
- „Noch schwierig“, „nichts verändert“ und „später“ verursachen weder Druck noch Verlust alter Entwicklung.
- Neue Aktivität verhindert unpassende Wiederholung; unabhängige offene Gedanken verschwinden nicht versehentlich.
- Backup/Import, Migration von F, Offline-Reload und bewusster Service-Worker-Wechsel erhalten alle Quellenverknüpfungen und Entwürfe.
- Keine konkurrierenden Datenmodelle für dieselbe Geschichte; keine ungeprüften Verbindungen durch bloße Textähnlichkeit.

## Was noch bewiesen werden muss

Die Stärke dieser Positionierung ist eine Hypothese. In einem kleinen Test beobachten: Verstehen Menschen den Zusammenhang ohne Erklärung? Greifen sie einen echten Gedanken nach einigen Wochen wieder auf? Hilft die Gegenüberstellung? Kehren sie freiwillig zurück? Erst anschließend Zahlungsbereitschaft testen. Rückkehr allein beweist noch keinen persönlichen Nutzen.

Nutzerrückmeldungen freiwillig und ohne standardmäßiges Einsammeln privater Glaubenstexte auswerten. Keine Marktexklusivität, spirituelle Wirksamkeit oder Zahlungsbereitschaft aus einer guten Demo ableiten.


## Ergänzung: Gedanken bekommen eine Fortsetzung

Vom Nutzer ausdrücklich zur Aufnahme in die nächste Build-Planung bestätigt.

Zusätzliches Produktversprechen: **FaithPath gibt deinen Glaubensgedanken eine Fortsetzung.** Die bestehende Markenpositionierung und Leitfrage bleiben erhalten.

1. **Eine fortlaufende Geschichte je Gedanke.** Rückblicke hängen sichtbar am ursprünglichen Gedanken. Mehrere Antworten über Wochen oder Monate bleiben chronologisch zusammen. Schwierige Zwischenstände werden nicht durch spätere positive Antworten ersetzt. Beispiel (fiktiv): Januar „Ich möchte geduldiger werden“, Februar „Im Streit klappt es weiterhin kaum“, April „Heute habe ich zugehört, obwohl ich wütend war“.
2. **Konkrete persönliche Nachfrage.** Gespeicherte Vorhaben aufgreifen: „Du wolltest im nächsten schwierigen Gespräch zuerst zuhören. Wie ist es dir damit gegangen?“ Tatsächlichen Wortlaut oder eindeutig belegten Kontext verwenden, keine erfundenen Absichten. Keine KI erforderlich. Eine allgemeine Schreib-Erinnerung erfüllt diese Vorgabe nicht.
3. **Die Bedeutung bestimmt der Nutzer.** Ergänzende Antwortmöglichkeiten vorsehen: „Das beschäftigt mich weiterhin“, „Ich sehe es heute anders“ und „Das möchte ich loslassen“. Loslassen bedeutet bewusster Abschluss, nicht Löschen oder Versagen. Automatische Wiedervorlagen dafür beenden; Geschichte und bisherige Entwicklung erhalten. Spätere Wiederaufnahme ermöglichen. Keine dieser Antworten ist automatisch ein Meilenstein.
4. **Der Olivenbaum führt zu echten Momenten.** Beim Öffnen die tatsächlich dokumentierten Entwicklungen und ihre Quellen auffindbar machen. Keine erfundene Ast-Zuordnung. Ein Schrittabschluss oder eine hohe Nutzungsfrequenz lässt den Baum weiterhin nicht wachsen.

Zusätzliche Abnahme: Eine Folge aus Ursprung und mindestens zwei Rückblicken muss vollständig auffindbar bleiben. „Anders sehen“ und „Loslassen“ müssen ohne Punkte, automatisches Wachstum oder Datenverlust funktionieren. Persönliche Nachfrage darf nur vorhandene eigene Inhalte verwenden. Bewusstes Loslassen beendet passende Wiedervorlagen, ohne unabhängige offene Gedanken zu verbergen.

Diese Ergänzung dokumentiert die nächste Produktarbeit. Sie ändert weder den aktuellen Build noch belegt sie weltweite Einzigartigkeit. Der konkrete Ablauf wird vor zusätzlichen Funktionen priorisiert.
