# Phase 1 — unabhängiges Audit, 16.09.2026

Ausgangspunkt: Repository akwasiacheampongma-code/Faithpath-, develop/v4, Commit 3c5b221ac958775588a62b49fbc9df5e82eed482, Build E. Unveränderte lokale Sicherung (Remote-Schreibzugriff verweigert): Branch backup/v4-e-20260916. Die zuvor gespeicherte ZIP D war älter. Keine AGENTS.md vorhanden.

## Inventar
Statische Vanilla-JavaScript-PWA: monolithische app.js, styles.css, index.html, sw.js, Netlify-Konfiguration. 165 versionierte Dateien inklusive veralteter app.js.pre_final_e. 18 Situationen; 4 geführte Pläne mit 24 Abschnitten; 3 Einsteigerführungen mit 16 Abschnitten; 17 Wegkategorien. Reader, einzelne zusammenhängende Verse, Markierung, Notiz, Wegverbindung, Kopieren, Übersetzungswechsel. Wege mit Schritten, Rückblicken und Meilensteinen. Journal, Quiz, Historie, JSON-Backup, drei Onboardingseiten, sieben unveränderte Baum-WebPs.

Beide Bibeln: 66 Bücher / 1.189 Kapitel. OTB: 31.103 Verse. Luther 1912: 31.102. Tatsächliche Dateicodes MRK, JHN, JAS usw.; Aliase mar, joh, jak vorhanden. 84 Referenzen der Orientierung und Führungen existieren in beiden Übersetzungen. 312 Story-/Kapiteleinheiten, 1.560 Quizfragen mit je vier unterschiedlichen Optionen, 27 NT-Bücher, 312 unterschiedliche Reflexionsfragen. 20 Einheiten/100 Fragen tragen einen übernommenen Prüfvermerk. 32 Einheiten/160 Fragen haben keinen solchen Vermerk. 260 Einheiten/1.300 Fragen sind source-extractive-luther1912. Ein vorhandener Prüfvermerk ist kein von diesem Audit durchgeführter theologischer Vollreview. 12 Johannes-Einheiten verwenden to:999 für das ganze Kapitel.

## Storage
- faithpath.v1.rebuild: version 4; paths (steps, links, reviews, milestones), journal, highlights, reflections, events, quiz, reading, translation, reminderSnoozes, dismissedGaps.
- faithpath.guidedPlans.v1: Plan-ID → Abschnittsindex → boolean.
- faithpath.onboarding.v4: done; früher faithpath.onboarding.v3.

## Kritische Befunde
1. load() fängt beschädigtes JSON ab, erzeugt fresh() und überschreibt direkt anschließend den Originalstand. Textnormalisierung kürzt lange Texte; unbekannte Felder werden verworfen.
2. Import setzt Speicherbereiche getrennt und ersetzt Daten ohne Vorschau oder Sicherung; fehlende Versnummern werden nicht vollständig validiert.
3. Service Worker aktiviert sich sofort, löscht alle Caches der Origin und mischt unversionierte Netzwerkdateien mit Caches. Kein belastbarer Offline-Bereitschaftsstatus.
4. Wege sind primär Karten/Checkboxen. Keine eigene vollständige Wegchronologie; Journal nicht gezielt mit Wegen verbindbar.
5. Erinnerungslücken berücksichtigen nur Wege und Markierungen, die tatsächliche letzte Aktivität eines Weges kaum. Weitere Lücken auf der Startseite nicht direkt erreichbar.
6. Guided Plans bieten Lesen + Abhaken, aber keine integrierte Reflexion/Schritt/Rückblick-Verbindung.
7. Modal ohne Fokusmanagement, klickbare Verse als div, viele unbeschriftete Formulare, sehr kleine sekundäre Texte.
8. Navigation ohne URLs; Reload verliert Ansicht; Bibel startet mit Geschichten. Journalfilter unvollständig, kein Suchfeld/Eintragsdetail.
9. Neu bestätigte Entwicklung kann ohne konkreten Text entstehen; Schritte selbst vergrößern den Baum richtigerweise nicht.
10. Keine unabhängigen automatisierten Tests im Repository. Aussagen früherer QA-Dokumente gelten nicht als Nachweis dieses Releases.

## Airtable (read-only)
Base FaithPath appolFXm1sS6OBpYA; Tabellen Einheiten und Fragen. Aktuelle Metadaten melden 902 Einheiten und 5.317 Fragen; zwei Datensätze je Tabelle tatsächlich gelesen. Nicht mit dem eingebetteten App-Inhalt gleichzusetzen. Felder für Buch, Versspanne, Reflexion, Prüfstatus; vier Antworten, richtige Antwort, Versbeleg, Erklärung. Nichts überschrieben, kein Runtime-Zugang eingebaut.
