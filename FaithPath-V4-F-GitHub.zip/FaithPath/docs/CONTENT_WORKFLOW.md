# Airtable als Redaktion, Release als statischer Export

Das bestehende Airtable-Schema unterstützt Einheiten mit Buch, Versspanne, Einordnung, Reflexionsfrage und Prüfstatus. Fragen besitzen vier Antworten, eine richtige Antwort, Versbeleg und Erklärung. Es wurden keine Tabellen oder Datensätze verändert.

Empfohlener Freigabeprozess:

1. Redaktion bearbeitet Inhalte in Airtable. Neue Inhalte erhalten ausdrücklich „noch zu prüfen“; keine automatische Freigabe durch Generierung.
2. Ein Export enthält ausschließlich bewusst ausgewählte freigegebene Revisionen und ihre stabilen IDs. Unverifizierte Altinhalte bleiben getrennt gekennzeichnet. Airtable-ID und Release-ID werden in einer Mappingdatei gepflegt; bestehende IDs werden nicht neu durchnummeriert.
3. Referenzen gegen beide lokalen Übersetzungen prüfen. Bei Übersetzungsunterschieden passende Grenzen je Übersetzung festlegen oder den Inhalt aus der Freigabe zurückstellen. Redaktion bestätigt Eindeutigkeit, plausible Optionen und Erklärung.
4. Export zunächst auf einem Entwicklungsbranch als JSON ablegen. Bestehende IDs, Fragen und Nutzerfortschritt per Diff prüfen; nichts blind überschreiben.
5. `npm run validate`, `npm test` und Browserprüfung. Contentstatus aktualisieren, neue Build-ID, erst dann Release.

Die App liest ausschließlich statische JSON-Dateien im Release. Keine Airtable-Zugangsdaten im Frontend, keine Airtable-Verbindung für Endnutzer und kein Offline-Ausfall bei einer Störung des Redaktionssystems.

Dies ist ein dokumentierter Prozess. Ein automatischer Exportjob wurde noch nicht eingerichtet: Dafür müssen die autoritativen Datensätze und das ID-Mapping zwischen Airtable und dem vorhandenen lokalen Bestand redaktionell festgelegt werden.
