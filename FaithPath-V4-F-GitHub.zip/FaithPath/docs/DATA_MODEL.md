# Speicherung und Migration

Schema 5 bleibt im bisherigen Hauptkey. Unbekannte Felder werden mitgeführt, Texte nicht gekürzt. Alle neuen Änderungen gehen erst in eine Kopie und werden nach Validierung mit einem einzigen `setItem` gespeichert. Ein Quota-Fehler lässt den vorherigen Stand bestehen. Ein inzwischen von einem anderen Tab veränderter Stand wird nicht überschrieben.

| Storage-Key | Bedeutung / Behandlung |
| --- | --- |
| `faithpath.v1.rebuild` | Bestehender Hauptstand; in F Schema 5. Wege, Journal, Markierungen, Reflexionen, Quiz, Historie und jetzt auch Planfortschritt |
| `faithpath.guidedPlans.v1` | Bisheriger separater Planfortschritt. Bei erstmaliger Migration übernommen, alter Key nicht gelöscht; danach ist der Hauptstand maßgeblich |
| `faithpath.onboarding.v4` | Vorhandener Einführungsstatus |
| `faithpath.onboarding.v3` | Älterer Einführungsstatus wird berücksichtigt |
| `faithpath.backup.pre-v5` | Neu: exakter alter Haupttext und alter Plantext vor erster Schema-Migration; nicht bei jedem Start überschrieben |
| `faithpath.backup.before-import` | Neu: unmittelbar vor dem letzten Import gesicherter Stand; über „Mehr“ wiederherstellbar |
| `faithpath.draft.v4` | Neu: aktiver Schreibentwurf einschließlich Kontext. Wird nach erfolgreichem Speichern entfernt |

Neue Verbindungen nutzen stabile IDs: Journal → `reflectionId`, Journal/Reflexion → `pathIds`, Weglink → `journalId`/`reflectionId`, Meilenstein → `reviewId`. Alte Journal-/Reflexionsspiegel werden nur bei exakt gleichem Text, Datum und Referenz miteinander verbunden. Ähnliche Formulierungen erzeugen keine automatische Verbindung.

Erinnerungen werden aus den vorhandenen Daten abgeleitet, nicht als spirituelle Aussage interpretiert. Standard: Wege nach 21 Tagen, unverbundene Einträge/Markierungen nach 35 Tagen. Nutzer können konkrete spätere Zeitpunkte wählen oder eine Erinnerung beiseitelegen. Jüngere Aktivität, letzte Rückblicke und gespeicherte Antworten verhindern unpassende sofortige Wiederholungen. Alte Datumswerte bleiben erhalten; ungültige Datumswerte erzeugen keine erfundene Chronologie.

Neue Entwicklungen benötigen eine ausdrückliche Bestätigung im Rückblick. Bestehende Meilensteine bleiben als damalige Dokumentation erhalten. Ein Schrittabschluss zählt nicht als Entwicklung. Archivierte Wege behalten alle Meilensteine. Nur bewusstes endgültiges Löschen entfernt einen Weg samt seiner eigenen Rückblicke; Journal und Markierungen bleiben erhalten.

Import: Dateityp/Struktur und Referenzen prüfen → Anzahl anzeigen → bewusste Wiederherstellung → vorherigen Stand sichern → Hauptkey atomar ersetzen. Kein Zusammenmischen zweier unabhängiger Backups. Leere, beschädigte, doppelte IDs oder unbekannt neuere Schemas werden zurückgewiesen. Originaldaten eines beschädigten Speichers können separat exportiert werden.
