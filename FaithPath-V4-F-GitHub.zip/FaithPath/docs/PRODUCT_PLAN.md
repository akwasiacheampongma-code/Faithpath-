# Phase 2 — Produktplan

MUSS: zusammenhängender Ablauf Situation/Lesen → Einordnung → Reflexion → optionaler Weg → kleiner Schritt → späterer Rückblick; sanfte Erinnerungen anhand echter Datenspuren; chronologische, anklickbare Geschichte je Weg und insgesamt. Bestehende Daten vor Migration sichern; beschädigten Stand niemals ersetzen; atomare Speicherung/Importsicherung; unabhängige Validierung echter Bibelreferenzen. Eigenständige Absichten Lesen/Entdecken; vier Hauptziele Heute, Bibel, Mein Weg, Journal; Mehr oben. Hauptaktion pro Screen, Details auf Wunsch. Ruhige, lesbare Darstellung mit Tastaturbedienung und echten Formularlabels. Versioniertes Offline-Release und sichtbarer Updateknopf.

SOLLTE: Suche und Filter, Wiederaufnahme der letzten Bibelstelle, Schrittvorschläge und bewusst gewählte Erinnerungszeit, entkoppelte Inhalts-/Speicher-/Darstellungsmodule, nachvollziehbarer Contentstatus, barrierearme Dialoge und wiederherstellbare Entwürfe, Archiv für ruhende Wege.

SPÄTER: vollständig redaktionell überarbeiteter Fragenkatalog; separat freigegebener Airtable-Export; echte Baumast-Zuordnung; optional verschlüsselte Synchronisation und echte Systembenachrichtigungen. Keine neuen Quizfragen, kein Chatbot, keine Scores, keine Streaks, keine Cloudpflicht.

Erfolgskriterium: Ein Nutzer findet einen konkreten früheren Gedanken wieder, hält selbst fest, was daraus geworden ist, und erkennt den Zusammenhang in seinem Weg. Erst das erfüllt den FaithPath-Kern.

## Vorgabe für den nächsten Build

Die am 17.09.2026 beauftragte USP-Schärfung und der gezielte Wettbewerbsvergleich stehen in [USP_NEXT_BUILD.md](USP_NEXT_BUILD.md). Vor der nächsten Implementierung berücksichtigen: Schwerpunkt „Damals & heute“, konkrete Ursprungs-/Rückblickverknüpfungen, eigene Einordnung des Nutzers; keine behauptete Marktexklusivität. Diese Ergänzung ändert den ausgelieferten Build F noch nicht.
