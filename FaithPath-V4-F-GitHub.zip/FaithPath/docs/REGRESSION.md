# Funktionsvergleich mit Build E

Ausgangspunkt Commit `3c5b221`; verglichen mit V4 F. Die automatisierten Prüfsummen für alle Quiz-/Reflexionsinhalte, Bibeldateien, Baum- und Iconassets stammen aus diesem unveränderten Commit.

| Funktion aus dem Ausgangsprojekt | Zugriff / Verhalten in F | Nachweis |
| --- | --- | --- |
| Heute und situationsbezogener Einstieg | Orientierung als Hauptaktion, direkte Bibel daneben | Browser: neuer Nutzer |
| 18 Situationen mit passenden Texten | Orientierung → Situation → Text im Kapitel | Inhaltsvalidator + Browser |
| Beide Offline-Bibeln | Bibel → Buch → Kapitel → Übersetzung | Unveränderte Dateien; beide Übersetzungen offline nach Reload gelesen |
| Versauswahl / Markierung | Tastaturfähige Versbuttons und Auswahlleiste | Browser: erfahrener Nutzer |
| Notiz / Weg verbinden / Kopieren | Auswahlleiste; Journal- und Wegverknüpfung | Browser: erfahrener Nutzer |
| Markierungen ansehen / entfernen | Bibel → Markierungen → Detail | Implementierung, Referenztests; lange Liste auf allen Viewports geprüft |
| Stories und Quiz | Bibel → Entdecken; Suche/Buch/Inhaltsart | 312/1.560 erhalten; Quizablauf im Browser |
| Quizfortschritt | Bisherige IDs und Abschlussdaten erhalten; Datum im Storydetail | Migrations-/Prüfsummentests und Browser |
| Persönliche Reflexion | Reader, Story oder Weg → Gedanken festhalten | Browserabläufe, keine Bewertung |
| Vier geführte Pläne | Mein Weg / Mehr → Geführte Wege | 24 Abschnitte und bestehender Fortschritt erhalten; Browser-Reload |
| Drei Einsteigerführungen | Orientierung / Geführte Wege | 16 Abschnitte und alle Referenzen validiert |
| Wege erstellen / bearbeiten / archivieren | Mein Weg und Wegverwaltung | Browser: Erstellen und Archivieren; Datenmodelltests |
| Eigene und vorgeschlagene Schritte | Weg → Schritt hinzufügen; Anregungen aufklappbar | Eigener Schritt im Browser; ursprüngliche Kategorien und Vorschläge übernommen |
| Entwicklung / Meilensteine | Rückblick mit zusätzlicher eigener Bestätigung | Browser + Domänentests; Checkboxen wachsen nicht |
| Sieben Baumstufen | Mein Weg → Olivenbaum | Assetprüfsummen, Stufenlogik; Archiv bewahrt Meilensteine |
| Erinnerungslücken / später erinnern | Heute und Offene Rückblicke | Browser + Datums-/Deduplizierungstests |
| Journaltypen / Predigtnotizen / Datum | Chronologie, Filter, Suchfeld, Detail | Browser: Predigtnotiz → Filter → Suche → Öffnen |
| Historie | Meine Geschichte und Verlauf jedes Weges | Browser und Domänentests; Links sind anklickbar |
| JSON-Export / Import | Mehr; jetzt mit Vorschau und vorheriger Sicherung | Browser-Rundreise, beschädigte Datei, Unit-Tests |
| Onboarding überspringen | Direkt zur Bibel; Einführung später in Mehr | Browser-Smoke und vollständiger Erstablauf |
| PWA / Netlify | Eigenständiger `dist/`-Build | Produktionsbuild, Offline-Neustart, echter E→F-Updateablauf lokal |

Bewusst verändert: Quiz hat keine Punktesicht; persönliches Wachstum wird nicht automatisch aus Schritten abgeleitet. Historische Ereignisfelder bleiben gespeichert. Die neue verständliche Chronologie zeigt originale Lesespuren sowie strukturierte Einträge und Wegereignisse, keine doppelten alten technischen Logmeldungen. Die Navigation wurde reduziert, die oben aufgeführten Funktionen bleiben erreichbar.

Nicht als nachgewiesen ausgegeben: echte iPhone-Installation, VoiceOver, Safari-Cachebereinigung, Netlify-Production-CDN oder eine theologische Prüfung aller Inhalte. Diese Grenzen stehen in KNOWN_ISSUES.md.
