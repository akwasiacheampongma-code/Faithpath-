# Produktresearch und eigene Ableitungen

Quellen am 16./17.09.2026 gelesen. Die folgenden Übertragungen sind eigene Produktentscheidungen, keine kopierten Oberflächen.

| Beobachtung / Quelle | Übertragung auf FaithPath |
| --- | --- |
| Day One beschreibt „On This Day“, Suche, Tags und Filter sowie Export und Privatsphäre. [Offizielle Featureübersicht](https://dayoneapp.com/features/) | Frühere eigene Gedanken wieder auffindbar machen. FaithPath ergänzt eine explizite Frage nach ihrer weiteren Entwicklung und den Zusammenhang eines persönlichen Weges. Streaks werden nicht übernommen. |
| YouVersion strukturiert seine Hilfen nach Bibel-App, Plattform und Nutzungsabsicht. [Offizieller Support](https://help.youversion.com/l/en) | Bibellesen muss direkt und vertraut erreichbar sein. FaithPaths Unterscheidung „Lesen / Entdecken“ dient unterschiedlichen Absichten; der eigene Schwerpunkt bleibt die persönliche Geschichte. Kein Anspruch auf einen vollständigen Produkttest von YouVersion. |
| W3C beschreibt für WCAG 2.2 AA grundsätzlich mindestens 24 × 24 CSS-Pixel bzw. definierte Abstände/Ausnahmen. [SC 2.5.8](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html) | FaithPath setzt für wesentliche Bedienflächen mindestens etwa 44 Pixel an, zusätzlich Fokus, Labels und Schriftvergrößerung. 44 Pixel wird nicht fälschlich als allgemeine AA-Grenze bezeichnet. |
| Der Service-Worker-Lebenszyklus trennt Installation, Warten und Aktivierung. [web.dev](https://web.dev/articles/service-worker-lifecycle) | Vollständigen neuen Build laden, vor dem Wechsel warten, Entwürfe erhalten. Keine automatische Reload-Schleife und kein Löschen fremder Caches. |
| Netlify unterstützt Publish-Verzeichnis und Build-Befehl in `netlify.toml`, Headerdateien und SPA-Rewrites. [Konfiguration](https://docs.netlify.com/build/configure-builds/file-based-configuration/), [Headers](https://docs.netlify.com/manage/routing/headers/), [Rewrites](https://docs.netlify.com/manage/routing/redirects/rewrites-proxies/) | Ein reproduzierbarer `dist/`-Build; fehlende JSON-/Code-Dateien liefern 404 statt scheinbar erfolgreichem HTML. Hash-Navigation, Root-Basis und versionierte Assets erleichtern Reload und Offline-Konsistenz. |

Apple HIG „Onboarding“ wurde aufgerufen, lieferte im verfügbaren Zugriff jedoch nur die JavaScript-Hülle. Daraus werden keine überprüften Detailaussagen abgeleitet. Hallow wurde nicht vollständig getestet. Es wird keine breitere Wettbewerbsstudie behauptet.

Eigene Gestaltungsprinzipien: eine Hauptaktion pro Ansicht; Anleitung beim Einstieg, direkter Reader für Erfahrene; Chronologie statt Kennzahlen-Dashboard; sekundäre Verwaltung in aufklappbaren Bereichen; warme Papierflächen, zurückhaltende Oliventöne und Serifentypografie zum Lesen. Die vorhandenen Baumbilder bleiben erhalten. Die App setzt weder einen Glaubenswert noch geistliche Rangfolgen voraus.

Warum FaithPath neben einer Bibel-App? Weil ein konkreter Gedanke vom Lesen über die Reflexion und den Alltag bis zum späteren Rückblick zusammenbleibt. Das ist die Produktleistung; die Menge von Fragen, Leseplänen oder Bibelübersetzungen ist es nicht.

Die vorbereitete CI orientiert sich an den aktuellen offiziellen READMEs für [Checkout](https://github.com/actions/checkout) und [Setup Node](https://github.com/actions/setup-node). Remote wurde sie mangels Schreibzugriff noch nicht ausgeführt.
