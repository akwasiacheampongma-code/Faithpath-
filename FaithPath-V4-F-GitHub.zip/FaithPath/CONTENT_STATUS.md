# Contentstatus — V4 F

Die Angaben stammen aus den tatsächlichen Dateien, nicht aus früheren README-Zahlen. `npm run validate` erzeugt `data/content-report.json` und den Referenzindex.

| Bestand | Ergebnis |
| --- | --- |
| OTB Deutsch | 66 Bücher, 1.189 Kapitel, 31.103 Verse |
| Luther 1912 | 66 Bücher, 1.189 Kapitel, 31.102 Verse |
| Story-/Kapiteleinheiten | 312, verteilt über 27 NT-Bücher |
| Quizfragen | 1.560; alle unverändert erhalten |
| Persönliche Reflexionsfragen | 312 unterschiedliche; ohne Bewertung |
| Situationen | 18 |
| Geführte Pläne | 4 / 24 Abschnitte |
| Einsteigerführungen | 3 / 16 Abschnitte |
| Referenzen in Situationen und Führungen | 84; Buch, Kapitel und tatsächliche Verse in beiden Übersetzungen validiert |

## Redaktioneller Prüfstatus

| Status | Einheiten | Fragen | Aussage |
| --- | ---: | ---: | --- |
| VERIFIZIERT laut vorhandenem Vermerk | 20 | 100 | `verse-checked` gegen Luther 1912 aus Build E übernommen; keine erneute unabhängige Vollprüfung |
| ERZEUGT / NOCH ZU PRÜFEN | 260 | 1.300 | bestehende `source-extractive-luther1912`-Kapitelübungen; repetitive Fragen, redaktionelle Arbeit offen |
| PRÜFVERMERK FEHLT | 32 | 160 | Bestandsinhalte erhalten, nicht als verifiziert ausgegeben |
| NEU ERSTELLT in F | 0 | 0 | keine erfundenen Fragen hinzugefügt |

Technische Prüfungen: eindeutige Story-IDs, vier verschiedene Optionen, zulässiger Index der richtigen Option, vorhandene Erklärung/Versangabe und tatsächliche Referenzgrenzen. Eine plausibel formulierte theologische Auslegung kann nicht allein technisch freigegeben werden.

Die 12 historischen `to:999`-Werte in Johannes-Ganzkapiteleinheiten wurden durch die tatsächlichen Endverse ersetzt. Fragen, Antworten, Erklärungen, IDs und Reflexionen blieben unverändert. Für historische Nutzerreferenzen versteht die Migration weiterhin den dokumentierten Ganzkapitel-Sentinel.

Bibeldateien und Lizenzhinweise sind bytegleich zum Ausgangsprojekt. OTB: CC BY-SA 4.0, Luther 1912: vorhandener gemeinfreier Text. Quellen und Lizenzlinks sind unter „Mehr → Bibeltexte & Lizenzen“ erreichbar.

## Airtable

Die FaithPath-Base meldete beim Audit **902 Einheiten und 5.317 Fragen**. Schema und je zwei Datensätze wurden gelesen. Diese Metadatenzahlen sind kein Nachweis, dass alle Airtable-Inhalte lokal enthalten, vollständig geprüft oder gegeneinander abgeglichen sind. Es wurde nichts überschrieben und nichts automatisch importiert. Der ausgelieferte Offline-Bestand bleibt 312 / 1.560.

[Redaktioneller Exportprozess](docs/CONTENT_WORKFLOW.md). Fehlend: vollständiger redaktioneller Abgleich von Airtable und lokalem Bestand, AT-Storykatalog und neue freigegebene Führungen für bisher nicht abgedeckte Themen.
