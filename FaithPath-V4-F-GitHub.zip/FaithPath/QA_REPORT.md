# QA-Ergebnis — FaithPath V4 F

**Build:** `FP4-20260916-F` · **Datum:** 17.09.2026 · **Referenz:** Build E / Commit `3c5b221`.

## Ausgeführt und bestanden

| Prüfung | Ergebnis |
| --- | --- |
| Kernlogik, Migration, Backups und Inhaltsregression | **22 / 22 bestanden** |
| Browser-Akzeptanzgruppen | **12 / 12 bestanden** |
| Service-Worker-Updateszenarien | **3 / 3 bestanden** |
| axe-Prüfungen auf 8 Ansichten/Formularen | **keine gemeldeten Verstöße** im gewählten WCAG-A/AA-Regelsatz |
| Referenzprüfung | 84 Situations-/Planreferenzen sowie alle Story- und Quizreferenzen gegen beide tatsächlichen Bibeldatensätze; keine technischen Fehler |
| Inhaltserhaltung | Alle 1.560 Fragen und 312 Reflexionsfragen identisch; alle Bibeldateien, sieben Baumassets und Icons per SHA-256 mit Build E verglichen |
| Produktionsbuild | `npm run build` erfolgreich; `dist/` enthält 161 Dateien einschließlich Integritätsmanifest |
| Nicht abgefangene Browserfehler | Keine in den bestandenen Ablaufprüfungen |

Werkzeuge: Node.js 24.19.0, Playwright 1.62.1, Chromium 153, axe-core 4.13.0. Der Chromium-Browser wurde in einer lokalen Testumgebung ausgeführt, mit dem Produktionsbuild, Service Worker und der Content Security Policy aus dem Projekt. Keine Echtdaten eines Nutzers: synthetische Testdaten.

## Tatsächlich durchgeklickte Abläufe

1. Drei Onboardingseiten → Situation → Text im Zusammenhang → Reflexion → neuer Weg mit Schritt und verknüpfter Bibelstelle.
2. Buchsuche Römer → Kapitel 12 → Vers 12 markieren → Notiz → vorhandener Weg → Übersetzungswechsel → Tastaturauswahl → Kopieren.
3. Schritt ausprobieren, eigenen weiteren Schritt anlegen, Reflexion, Rückblick mit Pflichttext und eigener Entwicklungsbestätigung. Archivieren behält den Meilenstein.
4. Alter Journaleintrag → spätere Erinnerung; alte Markierung → „Ich arbeite noch daran“ → gespeicherter Rückblick. Keine automatische Entwicklung.
5. Predigtnotiz → Filter → Suche → Detail → gesamte Chronologie.
6. Story → fünf Fragen mit Erklärung → Abschluss → persönliche Reflexion; keine Punkte.
7. Geführter Abschnitt → Reflexion → Fortschritt → Browser-Reload.
8. Echter Browserdownload eines Backups → Importvorschau → Wiederherstellung mit identischem Stand; beschädigtes JSON verändert nichts.
9. Bestätigte Offline-Bereitschaft → Verbindung abschalten → Reload → Genesis 50 in beiden Übersetzungen lesen → erneuter Reload.
10. Ungültiger Vers, fehlende Bibeldatei, beschädigter Hauptspeicher: verständliche Fehler und Erhalt der Originaldaten.
11. 320×568, 390×844, 768×1024 und 1440×1000; sehr langer Wegname, langer Text ohne Leerzeichen, über 180 Journaleinträge und 120 Markierungen. Keine horizontale Seitenüberbreite. Pagination, Textvergrößerung, Sprunglink, Escape und Reduced Motion geprüft.
12. Direkte tiefe URL und Reload laden den Reader mit korrekten Asset-Pfaden.

## Updates

- Originale E-Dateien starten, Legacy-Daten einsetzen, F auf derselben Test-Origin bereitstellen, Update bewusst aktivieren. Lange Texte, Wege, Meilensteine, Markierungen, Quiz, unbekannte Felder und separater Planfortschritt bleiben erhalten; exakte Originaldatensicherung vorhanden.
- F → isolierter Folge-Testbuild: Installation wartet während eines offenen Entwurfs; bewusster Wechsel und Wiederaufnahme des Entwurfs funktionieren.
- Absichtlich unvollständiger Folge-Testbuild: Installation wird abgebrochen. Die vorherige vollständige Version startet weiterhin offline. Ein fremder Cache bleibt in allen neuen Aktivierungen erhalten.

## Visuelle und Accessibility-QA

Die tatsächlich gerenderten mobilen Ansichten von Start, Reader, Weg, Rückblick, Journalverlauf und Quiz wurden anhand von Screenshots geprüft. Wesentliche Bedienflächen sind ca. 44 Pixel oder größer, Formulare beschriftet, Verse mit Tastatur bedienbar. Der Text wächst mit der Schriftpräferenz. Acht axe-Prüfungen umfassen Reader, Weg, Rückblickdialog, Historie, Journalhistorie, Quiz, Mehr und Heute.

Gefundene und behobene Probleme: kurzfristig veralteter Reader beim Übersetzungswechsel; falscher Updatehinweis während der Erstinstallation; zu frühe Offline-Anzeige; Dialog blieb bei Browsernavigation offen; Entwurf wurde beim Reload der Composer-Route nicht sichtbar fortgesetzt; Sprunglink kollidierte mit Hash-Navigation; zu kleine einzelne Touchfläche; veraltete Erinnerung trotz neuer Wegaktivität.

## Grenzen der Aussage

Kein realer iPhone-/Safari-/VoiceOver-Test, kein tatsächlicher Netlify-Production-Deploy und keine vollständig redaktionelle oder theologische Freigabe. Die automatisierte Prüfung ist keine WCAG-Zertifizierung. Root-Schriftvergrößerung und responsive Viewports ersetzen keinen vollständigen Zoomtest mit allen Browsern. Quota-Fehler wurden im Speichermodell simuliert, keine echte iOS-Speicherbereinigung durchgeführt.

**Einschätzung:** Geeignet für einen geschlossenen begleiteten Pilottest. Für einen öffentlichen Bezahltest stehen der echte Gerätetest, Live-Deploy und die bewusste Contentfreigabe aus. Weitere Grenzen: KNOWN_ISSUES.md.

Maschinenlesbare Ergebnisse: `docs/qa/unit-results.xml`, `browser-results.json`, `service-worker-results.json`, `accessibility-results.json`. Screenshot-Beispiele im Projektpaket: `docs/qa/`.
