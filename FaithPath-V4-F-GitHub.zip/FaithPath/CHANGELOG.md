# Änderungen — FaithPath V4 F

Build `FP4-20260916-F`, 17.09.2026. Grundlage: Build E, Commit `3c5b221`.

- Hauptbereiche neu geordnet: Heute, Bibel, Mein Weg und Journal; Entdecken, Rückblicke und geführte Wege bleiben klar erreichbar.
- Start bei einer Situation oder direkt in der Bibel. Einordnungen und Fragen führen zur Reflexion, zur Wegverbindung und zum eigenen Schritt.
- Jeder Weg hat eine anklickbare Chronologie aus Bibelstellen, Gedanken, Schritten und Entwicklungen. Das Journal verbindet Einträge sicher mit Wegen.
- Erinnerungslücken berücksichtigen Wege, Markierungen, Journal und Reflexionen sowie die jüngste Aktivität. Später erinnern und „Im Moment nicht“ ohne Abwertung.
- Rückblicke unterscheiden Gedanken, unveränderte Situationen und selbst bestätigte Entwicklung. Ein erledigter Schritt lässt den Baum nicht wachsen; Archivieren löscht keine Entwicklung.
- Reader mit Buchsuche, Kapitelwahl, Tastaturbedienung für Verse, Markierungen, Notizen, Kopieren und Übersetzungswechsel. Situationsbezogene Texte bleiben im Kapitelzusammenhang.
- Geführte Wege erhalten den bisherigen Fortschritt und integrieren eigene Reflexionen, Wege und Schritte.
- Journal mit Suche, Filtern, Details, Bearbeitung, Datum und chronologischem Verlauf. Schreibentwürfe können fortgesetzt werden.
- Alle 1.560 Fragen und 312 Reflexionsfragen erhalten; Prüfstatus sichtbar. Zwölf Ganzkapitel-Sentinels durch echte Endverse ersetzt.
- Schema-5-Migration mit Originaldatensicherung, atomare Speicherung, Importvorschau und Sicherung vor Import. Beschädigte Daten werden nicht geleert; konkurrierende Tabs werden erkannt.
- Releasegebundene Offline-Dateien, bestätigter Updatewechsel, keine automatische Aktualisierung während des Schreibens, Fremd-Caches bleiben erhalten.
- Neues responsives Design, echte Dialoge, Labels, Fokuszustände, skalierbare Schriften und Reduced Motion. Keine externen Fonts, Tracker oder Laufzeit-SDKs.
- Reproduzierbarer Build, Inhaltsvalidierung, Migrations-/Regressionstests, Browserabläufe, axe-Prüfungen und Service-Worker-Updateprüfungen ergänzt.
