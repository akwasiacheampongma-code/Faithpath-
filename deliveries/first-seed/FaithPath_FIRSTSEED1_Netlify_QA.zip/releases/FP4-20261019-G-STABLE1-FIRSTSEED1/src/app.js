import {createFirstSeedController} from './first-seed/controller.js';
import {renderOliveTree} from './olive-tree.js';
import {setupLivingMotion} from './living-motion.js';
import {createPwaController} from './pwa-controller.js';
import {createBibleLoader} from './bible-loader.js';
import {escapeHtml as e} from './view-html.js';
import {createBackupController} from './backup-controller.js';
import {createAppRouter} from './app-router.js';
import {writingDialog} from './verbunden/dialog-view.js';
import {prepareWritingArea} from './verbunden/interaction.js';
import {renderReaderFlow,readingTools} from './verbunden/reader-flow.js';
import {backupSummary} from './backup-model.js';
import {renderBackupPage} from './backup-view.js';
import {selectReminderControls,renderReminderControls,reminderWhy} from './reminders-view.js';
import {selectReviews} from './reviews-model.js';
import {renderReviewDetail,renderCompletedReviews,renderPendingReviews} from './reviews-view.js';
import {selectJournal} from './journal-model.js';
import {renderJournal,renderJournalResults,journalCount} from './journal-view.js';
import {onboardingContent} from './onboarding-view.js';
import {createDiscoveryIndex,selectDiscovery,DISCOVERY_PAGE_SIZE} from './discover-model.js';
import {renderDiscovery,renderDiscoveryResults,discoveryCount} from './discover-view.js';
import {renderMore} from './navigation-view.js';
import {capturePathReviewSource,reviewSourceContext,renderReviewSource} from './path-review-context.js';
import {selectTreeHistory,renderTreeJourney} from './tree-view.js';
import {selectPathsOverview,selectPathDetail} from './paths-model.js';
import {renderPathsOverview,renderPathDetail} from './paths-view.js';
import {swordExplanation} from './journey-view.js';
import {storyQuestionState,renderStoryQuestion} from './story-flow-view.js';
import {chapterOffer,chapterNavigation,initiallyVisibleChapterEnd,chapterOpeningBottom} from './reader-view.js';
import {selectToday} from './today-model.js';
import {renderToday} from './today-view.js';
import {beginDraftSession,saveDraft,clearDraft,discardDraft,completedDraft} from './drafts.js';
import {groupOriginPairs} from './journey-sword.js';
import {recordExploredChapter,observeChapterEnd} from './bible-journey.js';
import {journeyAcknowledgement,treeBranchView,pathFacts,themePicker} from './experience-view.js';
import {themeId,applyTheme,THEMES} from './themes.js';
import {createChapterCatalog,chapterUnit,chapterQuizRoute} from "./chapter-questions.js";
import {deleteJournalEntry,restoreJournalEntry,journalDraftMatches,setJournalPath} from "./journal-management.js";
import {journalTransaction,recoverJournalWrite,JOURNAL_WRITE_KEY,journalWriteActive} from "./journal-storage.js";
import {isBibleNote,bibleNotes,deleteBibleNote,restoreBibleNote} from "./bible-notes.js";
import {readingContext,previousThought,allReviews,reviewsFor,reviewPairs,highlightContext} from "./continuity.js";
import { HIGHLIGHT_COLORS, highlightColor, overlapsRef, paintRange, clearRange, detachPath } from "./core-experience.js";
import { closeMenu, menuMarkup } from "./menu.js";
import { createStore, KEYS, id, now } from "./store.js";
import {
  normBook,
  validRef,
  sameRef,
  gaps,
  timeline,
  treeLevel,
  attach,
  time,
} from "./domain.js";
import {
  LIFE_TOPICS,
  GUIDED_PLANS,
  BEGINNER_GUIDES,
  PATH_CATEGORIES,
  stageNames,
  TRANSLATIONS,
} from "./content.js";
import { BUILD } from "./version.js";
import { loadRuntimeModel } from "./runtime-model.js";
let runtimeModel;
const CONTENT_BASE = new URL("../data/", import.meta.url);

const $ = (s, r = document) => r.querySelector(s),
  $$ = (s, r = document) => [...r.querySelectorAll(s)];
const date = (d) =>
  time(d) == null
    ? "Datum unbekannt"
    : new Date(d).toLocaleDateString("de-DE", {
        day: "numeric",
        month: "long",
        year: "numeric",
      });
const shortDate = (d) =>
  time(d) == null
    ? ""
    : new Date(d).toLocaleDateString("de-DE", {
        day: "2-digit",
        month: "short",
      });
// Access through an adapter so a blocked browser storage API becomes a recoverable error.
let journalRecoveryError=null;
try{await recoverJournalWrite(window.localStorage);}catch(error){journalRecoveryError=error;}
const deviceStorage = {
  removeItem: k=>window.localStorage.removeItem(k),
  getItem: (k) => window.localStorage.getItem(k),
  setItem: (k, v) => {if(journalRecoveryError)throw journalRecoveryError;if(!journalWriteActive()&&localStorage.getItem(JOURNAL_WRITE_KEY))throw new Error("Ein Journal-Speichervorgang ist noch offen. Bitte lade FaithPath neu, bevor du weiterschreibst.");window.localStorage.setItem(k, v);},
};
const store = createStore(deviceStorage),
  s = () => store.state;
applyTheme(document,themeId(s()));
const ui = {
  books: [],
  stories: [],
  refs: {},
  contentStatus: {},
  route: "today",
  token: 0,
  selection: new Set(),
  reader: null,
  filter: "Alle",
  search: "",
  storySearch: "",
  storyBook: "",
  storyKind: "alle",
  storyLimit: DISCOVERY_PAGE_SIZE,
  historyLimit: 40,
  journalLimit: 40,
  reviewsLimit: 40,
  quiz: null,
  form: null,
  offline: false,
  waiting: null,
  archive: false,
  markColor: "", markBook: "", markContext: "",
};
const icons = {
  home: '<path d="m3 10 9-7 9 7v11h-6v-7H9v7H3Z"/>',
  book: '<path d="M12 5v16M12 5C9 3 5 3 2 4v15c4-1 7-1 10 2 3-3 6-3 10-2V4c-3-1-7-1-10 1Z"/>',
  path: '<path d="M7 21c-8-9 17-8 9-18M5 21h4M14 3h4"/>',
  pen: '<path d="m16 3 5 5-12 12-6 1 1-6ZM14 5l5 5"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  leaf: '<path d="M20 3C4 1 1 9 6 15c5 6 15 1 14-12ZM4 21 16 7M8 16l-1-6M12 12l5 1"/>',
  arrow: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
  back: '<path d="M20 12H4m6-6-6 6 6 6"/>',
  plus: '<path d="M12 4v16M4 12h16"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  search: '<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
  history: '<path d="M3 10a9 9 0 1 1 1 8M3 4v6h6M12 7v5l3 2"/>',
  check: '<path d="m4 12 5 5L20 6"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
};
const icon = (n) =>
  `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${icons[n] || icons.leaf}</svg>`;
const attrs = (o) =>
  Object.entries(o)
    .filter(([, v]) => v != null)
    .map(([k, v]) => `data-${k}="${e(v)}"`)
    .join(" ");
const button = (label, action, values = {}, cls = "button") =>
  `<button type="button" class="${cls}" data-action="${action}" ${attrs(values)} ${label === "Journaleintrag löschen" ? 'aria-label="Journaleintrag löschen"' : ""}>${label === "Journaleintrag löschen" ? "Journal<wbr>eintrag löschen" : label}</button>`;
const link = (label, route, cls = "text-link") =>
  `<a class="${cls}" href="#${e(route)}">${label}</a>`;
const row = (title, sub, route, kind = "") =>
  link(
    `<span>${kind ? `<span class="overline">${e(kind)}</span>` : ""}<strong>${e(title)}</strong>${sub ? `<small>${e(sub)}</small>` : ""}</span>${icon("arrow")}`,
    route,
    "list-row",
  );
const heading = (k, title, desc = "") =>
  `<header class="page-heading"><span class="overline">${e(k)}</span><h1 tabindex="-1">${e(title)}</h1>${desc ? `<p>${e(desc)}</p>` : ""}</header>`;
const back = (title, route) =>
  link(`${icon("back")}${e(title)}`, route, "back-link");
const empty = (title, text, cta = "") =>
  `<section class="empty"><span class="empty-icon">${icon("leaf")}</span><h2>${e(title)}</h2><p>${e(text)}</p>${cta}</section>`;
const category = (id) =>
  PATH_CATEGORIES.find((c) => c.id === id) || PATH_CATEGORIES.at(-1);
function notify(text, error = false) {
  const t = $("#toast");
  t.innerHTML = text.length > 90 ? `<details><summary>${e(text.slice(0,45))} … Mehr</summary><p>${e(text)}</p></details>` : e(text);
  if (error) t.insertAdjacentHTML("beforeend",button("Meldung schließen","dismiss-status",{},"text-button"));
  t.querySelector("details")?.addEventListener("toggle",()=>{if(t.querySelector("details").open)clearTimeout(notify.timer);});
  t.className = error ? "toast error visible" : "toast visible";
  clearTimeout(notify.timer);
  if (!error) notify.timer = setTimeout(() => t.classList.remove("visible"), 4500);
}
function showError(error) {
  const message =
    error?.message || "Das hat nicht funktioniert. Bitte versuche es erneut.";
  const field = $("#form-error");
  const backupField=$("#backup-error");
  if(backupField){backupField.textContent=message;backupField.focus();return;}
  if (field) {
    field.textContent = message;
    field.focus();
  } else notify(message, true);
}
function change(fn) {
  if(journalRecoveryError)throw journalRecoveryError;
  if(!journalWriteActive()&&localStorage.getItem(JOURNAL_WRITE_KEY))throw new Error("Ein Journal-Speichervorgang ist noch offen. Bitte lade FaithPath neu, bevor du weiterschreibst.");
  store.transact(fn);
}
const refLabel = (r) =>
  r.label ||
  `${ui.books.find((b) => b.code === normBook(r.book))?.name || r.book} ${r.chapter}${r.from ? "," + r.from + (r.to && r.to !== r.from ? "–" + r.to : "") : ""}`;
function readRoute(ref, origin = "") {
  const r = { ...ref, translation: ref.translation || s().translation };
  const q = new URLSearchParams();
  if (r.from != null) q.set("from", r.from);
  if (r.to != null) q.set("to", r.to);
  if (origin) q.set("origin", origin);
  return `read/${normBook(r.book)}/${r.chapter}/${r.translation}${q.size ? "?" + q : ""}`;
}
function go(route) {
  if (location.hash.slice(1) === route) render();
  else location.hash = route;
}
function shell(body, active = "today", cls = "") {
  ui.motionStop?.();
  ui.journeyStop?.(); ui.journeyStop=null;
  document.body.classList.remove("has-verse-selection");
  applyTheme(document,themeId(s()));
  closeMenu(false);
  const toast=$("#toast"); if(toast) document.body.append(toast);
  $("#app").innerHTML =
    `<header class="topbar"><a class="wordmark" href="#today" aria-label="FaithPath Startseite"><img class="brand-icon" src="./icons/olive-v2-192.png" alt="" aria-hidden="true" width="28" height="28" decoding="async"><span class="brand-name">FaithPath<span class="brand-dot" aria-hidden="true">.</span></span></a><div class="top-right"><span class="offline-label">${!navigator.onLine ? "Offline" : ui.offline ? "Auf diesem Gerät" : ""}</span><button type="button" id="menu-toggle" class="icon-button" aria-label="Hauptmenü öffnen oder schließen" aria-expanded="false" aria-controls="main-menu" aria-haspopup="dialog">${icon("more")}</button></div></header><div id="notification-slot"></div><nav class="primary-nav" aria-label="Hauptnavigation">${[
      ["today", "home", "Heute"],
      ["bible", "book", "Bibel"],
      ["paths", "path", "Mein Weg"],
      ["journal", "pen", "Journal"],
    ]
      .map(
        ([route, ic, t]) =>
          `<a href="#${route}" ${active === route ? 'aria-current="page"' : ""}>${icon(ic)}<span>${t}</span></a>`,
      )
      .join(
        "",
      )}</nav><div class="page ${cls}">${ui.waiting ? `<aside class="update-notice" role="status">Eine neue Version ist bereit. ${button("Jetzt aktualisieren", "update", {}, "text-button")}</aside>` : ""}${store.error ? `<aside class="error-notice" role="alert"><strong>Deine gespeicherten Daten brauchen Aufmerksamkeit.</strong><p>${e(store.error.message)} Der Originalstand bleibt erhalten.</p>${button("Originaldaten sichern", "raw-backup", {}, "text-button")}${link("Backup wiederherstellen", "more")}</aside>` : ""}<main id="main">${body}</main><footer class="page-footer">Deine persönliche Glaubensgeschichte.</footer></div>${menuMarkup(ui.route)}`;
  $("#notification-slot").append(toast);
  ui.navObserver?.disconnect();
  ui.navObserver=new ResizeObserver(entries=>{if(innerWidth<1100)document.documentElement.style.setProperty("--bottom-nav-height",entries[0].target.getBoundingClientRect().height+"px");});
  ui.navObserver.observe($(".primary-nav"));
  ui.tabsObserver?.disconnect();
  ui.tabsObserver=new ResizeObserver(()=>updateTabCues());
  for(const tabs of $$(".segmented")){ui.tabsObserver.observe(tabs);tabs.addEventListener('scroll',()=>updateTabCues(),{passive:true});}
  updateTabCues();
  ui.treeStages ||= new Map();
  ui.motionStop=setupLivingMotion($('#main'),{previousStages:ui.treeStages});
  document.title = `FaithPath · ${$("h1")?.textContent || "Deine persönliche Glaubensgeschichte"}`;
}
function updateTabCues() {
 for(const tabs of $$(".segmented")){
  const overflow=tabs.scrollWidth>tabs.clientWidth+2;
  tabs.classList.toggle('tabs-more-end',overflow&&tabs.scrollLeft+tabs.clientWidth<tabs.scrollWidth-2);
  tabs.classList.toggle('tabs-more-start',overflow&&tabs.scrollLeft>2);
  if(overflow)tabs.setAttribute('aria-description','Weitere Bereiche sind durch horizontales Scrollen erreichbar.');else tabs.removeAttribute('aria-description');
 }
}
function timelineHTML(items, limit = 40) {
  return items.length
    ? `<ol class="timeline">${items
        .slice(0, limit)
        .map(
          (x) =>
            `<li><time datetime="${e(x.at)}">${e(shortDate(x.at))}<span>${time(x.at) != null ? new Date(x.at).getFullYear() : ""}</span></time><div class="timeline-content"><span class="overline">${e(x.kind)}</span>${x.route ? link(e(x.title || (x.ref ? refLabel(x.ref) : x.kind)), x.route, "timeline-title") : x.ref ? link(e(x.title || refLabel(x.ref)), readRoute(x.ref), "timeline-title") : `<p class="preserve">${e(x.title)}</p>`}${storyConnections(x)}</div></li>`,
        )
        .join("")}</ol>`
    : "";
}
function hasPersonalHistory(data=s()) {
  return !!(data.paths.length || data.journal.length || data.reflections.length || data.highlights.length || data.reviews.length || Object.values(data.guidedPlans).some(p=>Object.values(p).some(Boolean)));
}
function canonicalStoryForLegacy(unit) {
  if(!unit || unit.kind === "chapter-quiz")return null;
  const mapping=runtimeModel.flow.mapping_links.find(l=>l.FP_ID===unit.questions[0]?.faithpath_id);
  return mapping ? runtimeModel.stories.get(mapping.Story_ID) : null;
}
function discoveryItems() {
  return [...runtimeModel.flow.stories,...ui.stories.filter(x=>x.kind==="chapter-quiz")];
}
function storyConnections(x) {
  const paths=[...new Set([...(x.pathIds||[]),...(x.pathId?[x.pathId]:[])])].map(id=>s().paths.find(p=>p.id===id)).filter(Boolean);
  const pieces=[...(x.ref?[link(e(refLabel(x.ref)),readRoute(x.ref))]:[]),...paths.map(p=>link("Teil deines Weges: "+e(p.title),"path/"+encodeURIComponent(p.id)))];
  return pieces.length ? `<div class="story-connections">${pieces.join("")}</div>` : "";
}
function home() {
  let draft = null;
  try { draft = JSON.parse(localStorage.getItem(KEYS.draft)); } catch {}
  const model = selectToday(s(), {draft});
  shell(renderToday(model, {e,link,button,icon,refLabel,readRoute,date,category}),
    "today", "home-page today-phase1 " + (model.returning ? "returning-home" : "first-home"));
}

function undoNotice(text, restore) {
  notify(text);
  const token = Symbol(); ui.undo = { token, restore, expires: Date.now() + 8000 };
  const toast = $("#toast"); toast.innerHTML = `${e(text)} · ${button("Rückgängig", "undo-core", {}, "text-button")}`;
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => { if (ui.undo?.token === token) ui.undo = null; toast.classList.remove("visible"); }, 8000);
}
function verseHighlight(v, ref) { return s().highlights.slice().reverse().find(h => normBook(h.book) === ref.book && +h.chapter === +ref.chapter && (h.translation || "otb") === ref.translation && v >= h.from && v <= (h.to || h.from)); }
function readerVerse(v, ref) {
  const h = verseHighlight(v[0], ref);
  return `<span role="button" tabindex="0" class="verse ${h ? "marked highlight-" + highlightColor(h) : ""} ${ref.from && v[0] >= ref.from && v[0] <= (ref.to || ref.from) ? "in-passage" : ""}" data-action="verse" data-v="${v[0]}" aria-pressed="false" aria-label="Vers ${v[0]}: ${e(v[1])}${h ? " · Markiert: " + HIGHLIGHT_COLORS[highlightColor(h)] : ""}"><sup>${v[0]}</sup><span>${e(v[1])}${h ? '<span class="sr-only"> · Markiert</span>' : ""}</span></span>` + verseContext(v[0],ref);
}
function refreshHighlights() {
  if (!ui.reader || !$(".reader-page")) return;
  $$(".verse-context").forEach(el=>el.remove());
  for (const el of $$(".verse")) {
    const n = +el.dataset.v, h = verseHighlight(n, ui.reader.ref);
    el.classList.remove("marked", ...Object.keys(HIGHLIGHT_COLORS).map(c => "highlight-" + c));
    if (h) el.classList.add("marked", "highlight-" + highlightColor(h));
    el.insertAdjacentHTML("afterend",verseContext(n,ui.reader.ref));
    el.setAttribute("aria-label", `Vers ${n}: ${ui.reader.vs.find(v => v[0] === n)?.[1] || ""}${h ? " · Markiert: " + HIGHLIGHT_COLORS[highlightColor(h)] : ""}`);
  }
}
function markNotes(h) { return bibleNotes(s(),h); }
function markPaths(h) { return s().paths.filter(p => p.links.some(l => l.ref && overlapsRef(l.ref, h))); }
function colorPalette(args) {
  const ref = args.ref || s().highlights.find(h => h.id === args.id);
  if (!ref) return;
  const existing = args.id ? s().highlights.filter(h => h.id === args.id) : s().highlights.filter(h => overlapsRef(h, ref));
  const colors = new Set(existing.map(highlightColor));
  modal("Markierung gestalten", `<p class="meta">${e(refLabel(ref))}</p><div class="highlight-palette" role="listbox" aria-label="Markierungsfarbe">${Object.entries(HIGHLIGHT_COLORS).map(([c,label]) => `<button type="button" class="color-choice highlight-${c}" role="option" aria-selected="${colors.size === 1 && colors.has(c)}" data-action="paint-highlight" data-color="${c}" data-ref="${e(JSON.stringify(ref))}" data-id="${e(args.id || "")}" tabindex="${(colors.size===1 ? colors.has(c) : c==='olive') ? 0 : -1}" data-active="${colors.size === 1 && colors.has(c)}"><span class="color-dot" aria-hidden="true">${colors.size === 1 && colors.has(c) ? "✓" : ""}</span><span>${label}</span></button>`).join("")}</div><p class="meta">Zum Wiederfinden.</p>${args.id ? button("Markierung entfernen", "remove-mark", {id:args.id}, "text-button danger-text") : existing.length ? button("Markierung entfernen", "remove-selected-highlight", {ref:JSON.stringify(ref)}, "text-button danger-text") : ""}`);
}
function safeReading() {
  const x=readingContext(s());if(!x)return null;
  try {return {...x,ref:validRef(x.ref,ui.refs)};}catch{return null;}
}

function continuityGroupsHTML(pairs,limit=Infinity) {
 return groupOriginPairs(pairs).slice(0,limit).map(group=>`<article class="continuity-pair" data-pair-kind="${e(group.pairs[0].kind)}"><span class="overline">Damals → Heute</span><div class="continuity-before"><span class="meta">Damals · ${date(group.before.date)}</span><blockquote>${e(group.before.text)}</blockquote></div>${group.pairs.map(pair=>`<div class="continuity-after continuity-today"><span class="meta">Heute · ${date(pair.after.date)}</span><blockquote>${e(pair.after.text)}</blockquote>${link(pair.review?"Rückblick öffnen":"Gedanken ansehen",pair.after.route,"text-link")}</div>`).join("")}${storyConnections(group.before)}</article>`).join("");
}
function verseContext(n,ref) {
  const h=verseHighlight(n,ref);if(!h||n!==+h.from)return "";
  const c=highlightContext(s(),h),p=c.paths[0],j=c.notes[0];if(!p&&!j)return "";
  return `<aside class="verse-context continuity-strip" data-verse-context="${n}" aria-label="Dein Kontext zu dieser Stelle">${p ? `<p>Mit deinem Weg ${link('„'+e(p.title)+'“',"path/"+encodeURIComponent(p.id))} verbunden.</p>` : ""}${j ? `<p>${link("Dazu hast du etwas festgehalten.",j.route)}</p>` : ""}</aside>`;
}
function guidance() {
  shell(
    `${back("Heute", "today")}${heading("Orientierung", "Was beschäftigt dich?", "Diese Bibeltexte können dir helfen, über deine Situation nachzudenken. Du brauchst kein Vorwissen.")}${!hasPersonalHistory() ? `<aside class="beginner-entry continuity-strip">${row("Neu im Glauben","Du brauchst kein Vorwissen.","guide/start")}</aside>` : ""}<div class="topic-intro">${LIFE_TOPICS.filter(t=>["angst","wut","entscheidung","familie"].includes(t.id)).map((t,i)=>`<a class="topic-anchor topic-anchor-${i}" href="#topic/${e(t.id)}"><span class="topic-line" aria-hidden="true">${icon("leaf")}</span><h2>${e(t.title)}</h2><p>${e(t.sub)}</p></a>`).join("")}</div><details class="all-topics"><summary>Alle Themen</summary><div class="topic-grid">${LIFE_TOPICS.map(t=>row(t.title,t.sub,"topic/"+t.id)).join("")}</div></details><section class="section"><div class="section-heading"><h2>Lieber begleitet anfangen?</h2></div>${row("Geführte Wege", "Lesen, verstehen, ausprobieren und zurückblicken.", "plans")}${BEGINNER_GUIDES.map((g) => row(g.title, `${g.days.length} Abschnitte · in deinem Tempo`, "guide/" + g.id)).join("")}</section>`,
    "today", "guidance-page depth-page",
  );
}
function topic(id) {
  const t = LIFE_TOPICS.find((t) => t.id === id);
  if (!t) return notFound();
  shell(
    `${back("Orientierung", "guidance")}${heading("Was beschäftigt dich?", t.title, t.sub)}<p class="intro-note">Keine fertige Antwort auf dein Leben. Ein paar Texte, bei denen du anfangen kannst.</p><div class="passage-list">${t.refs.map((r, i) => `<article><span class="passage-number">0${i + 1}</span><div><h2>${e(r.label)}</h2><p>${e(r.context)}</p>${link(`Lesen & nachdenken ${icon("arrow")}`, readRoute(r, "topic/" + t.id + "/" + i), "text-link")}</div></article>`).join("")}</div>`,
  );
}
function planInfo(kind, pid) {
  return (kind === "guide" ? BEGINNER_GUIDES : GUIDED_PLANS).find(
    (p) => p.id === pid,
  );
}
function planRef(p, i) {
  const d = p.days[i];
  return { book: normBook(d[1]), chapter: d[2], from: d[3], to: d[4] };
}
function planProgress(kind, pid) {
  return s().guidedPlans[kind === "guide" ? "guide:" + pid : pid] || {};
}
// Descriptors reflect the existing section structure, not new content or scope.
function offerPurpose(p,kind) {
 if(kind==='guide'&&p.id==='start')return 'Grundlagen mit Lesehilfe';
 if(kind==='plan'&&p.id==='start7')return 'Grundlagen mit Reflexionsfragen';
 if(kind==='guide'&&p.id==='gebet')return 'Gebet · vier Einstiege mit Lesehilfe';
 if(kind==='plan'&&p.id==='gebet5')return 'Gebet · fünf Abschnitte zur Reflexion';
 return kind==='guide'?'Lesen mit einer kurzen Einordnung':'Lesen mit einer persönlichen Frage';
}
function plans() {
  const teaser=(p,kind)=>{const progress=planProgress(kind,p.id),last=Object.keys(progress).filter(k=>progress[k]).map(Number).sort((a,b)=>b-a)[0];return `<article class="guided-teaser"><span class="overline">${e(offerPurpose(p,kind))}</span><h2>${link(e(p.title.replace(/^\d+ Tage – /,"")),kind+"/"+p.id)}</h2>${p.sub ? `<p>${e(p.sub)}</p>` : ""}<div class="guided-structure"><span>${p.days.length} Abschnitte</span>${last != null && p.days[last] ? `<span>Zuletzt: ${e(p.days[last].title || p.days[last][0] || "Abschnitt " + (last+1))}</span>` : ""}</div>${link(last != null ? "Weiter begleiten lassen" : "Weg ansehen",kind+"/"+p.id,"text-link")}</article>`;};
  shell(`${back("Heute","today")}${heading("Geführte Wege","Ein Thema, das dich begleitet.","Lesen. Verstehen. Ausprobieren. In deinem Tempo.")}<div class="guided-teasers">${(hasPersonalHistory() ? [...GUIDED_PLANS.map(p=>teaser(p,"plan")),...BEGINNER_GUIDES.map(p=>teaser(p,"guide"))] : [...BEGINNER_GUIDES.map(p=>teaser(p,"guide")),...GUIDED_PLANS.map(p=>teaser(p,"plan"))]).join("")}</div>`,"today","plans-page depth-page");
}
function plan(kind, pid) {
  const p = planInfo(kind, pid);
  if (!p) return notFound();
  const pr = planProgress(kind, pid),
    n = Object.values(pr).filter(Boolean).length;
  shell(
    `${back("Geführte Wege", "plans")}${heading("Geführter Weg", p.title.replace(/^\d+ Tage – /, ""), p.sub || "Ein ruhiger Einstieg. Du gehst Abschnitt für Abschnitt.")}<p class="meta">${n} von ${p.days.length} Abschnitten festgehalten · dein Tempo</p><ol class="plan-sections">${p.days.map((d, i) => `<li><span class="section-number">${pr[i] ? icon("check") : String(i + 1).padStart(2, "0")}</span><div><h2>${e(d[0])}</h2><p>${e(d[d.length - 1])}</p><div class="actions">${link(pr[i] ? "Noch einmal ansehen" : "Lesen & reflektieren", readRoute(planRef(p, i), `${kind}/${pid}/${i}`))}${button(pr[i] ? "Wieder öffnen" : "Gelesen markieren", "plan-toggle", { kind, id: pid, day: i }, "text-button")}</div></div></li>`).join("")}</ol>`,
  );
}
function bible() {
  const reading=safeReading();
  shell(`${heading("Lesen","Die Bibel. Raum zum Verstehen.","Lies in deinem Tempo. Tippe auf einen Vers, um ihn zu markieren oder einen Gedanken festzuhalten.")}${reading ? `<section class="continue-reading continuity-strip"><span class="overline">Weiterlesen</span><span class="meta">Zuletzt gelesen${reading.at ? ' · '+date(reading.at) : ''}</span><h2>${e(refLabel(reading.ref))}</h2>${link("Weiterlesen",readRoute(reading.ref),"text-link")}</section>` : ""}<p class="bible-journey-entry">${link("Deine Bibelreise", "bible-journey", "text-link")}</p><div class="segmented" aria-label="Bibelbereiche">${link("Lesen","bible","active")}${link("Entdecken","discover")}${link("Markierungen","marks")}</div><div class="field"><label for="book-search">Buch finden</label><input type="search" id="book-search" data-input="books" placeholder="Zum Beispiel Römer" autocomplete="off"></div><div class="book-columns" id="book-list">${bookList()}</div>`,"bible","bible-page depth-page");
}
function bookList(query = "") {
  if(!ui.books.some(b=>(b.name+" "+b.code).toLowerCase().includes(query.trim().toLowerCase())))return `<section class="book-search-empty" role="status"><h2>Kein Buch gefunden.</h2><p>Suche hier nach einem Buchnamen, zum Beispiel: Johannes.</p><p class="meta">Eine konkrete Bibelstelle kannst du nach Auswahl des Buches über das Kapitel öffnen.</p>${button("Alle Bücher ansehen","reset-book-search",{},"text-button")}</section>`;
  query=query.trim();
  return [ui.books.slice(0, 39), ui.books.slice(39)]
    .map(
      (books, i) =>
        `<section><h2 class="overline">${i ? "Neues" : "Altes"} Testament</h2>${books
          .filter((b) =>
            (b.name + " " + b.code).toLowerCase().includes(query.toLowerCase()),
          )
          .map((b) =>
            row(b.name, `${b.chapters} Kapitel`, "chapters/" + b.code),
          )
          .join("")}</section>`,
    )
    .join("");
}
function chapters(code) {
  const b = ui.books.find((b) => b.code === code);
  if (!b) return notFound();
  shell(
    `${back("Bibel", "bible")}${heading("Kapitel wählen", b.name)}<div class="chapter-grid">${Array.from({ length: b.chapters }, (_, i) => link(String(i + 1), readRoute({ book: code, chapter: i + 1 }), "chapter-link")).join("")}</div>`,
    "bible",
  );
}
const getBook=createBibleLoader();

function contextOf(origin) {
  const [kind, pid, i] = origin.split("/");
  if (kind === "topic") {
    const t = LIFE_TOPICS.find((t) => t.id === pid),
      r = t?.refs[+i];
    if (r)
      return {
        title: t.title,
        context: r.context,
        question: r.question,
        category: t.category,
        origin,
      };
  }
  if (["guide", "plan"].includes(kind)) {
    const p = planInfo(kind, pid),
      d = p?.days[+i];
    if (d) {
      const matching = LIFE_TOPICS.flatMap((t) => t.refs).find(
        (r) =>
          normBook(r.book) === normBook(d[1]) &&
          r.chapter === d[2] &&
          r.from === d[3],
      );
      return {
        title: d[0],
        context:
          kind === "guide"
            ? d[5]
            : matching?.context ||
              "Lies den Abschnitt zunächst im Zusammenhang. Achte darauf, wer spricht und an wen sich der Text richtet.",
        question: d.at(-1),
        origin,
        planId: pid,
        planKind: kind,
        day: +i,
      };
    }
  }
  if (kind === "merged-story") {
    const x=runtimeModel.stories.get(pid);
    if(x)return {title:x.title,context:x.ref,question:x.reflection,storyId:x.story_id,origin};
  }
  if (kind === "story") {
    const x = ui.stories.find((x) => String(x.id) === pid);
    if (x)
      return {
        title: x.title,
        context: x.desc,
        question: x.reflection,
        storyId: x.id,
        origin,
      };
  }
  return null;
}
async function reader(parts, params, token) {
  const [_, code, chapter, tr0] = parts,
    tr = TRANSLATIONS[tr0] ? tr0 : s().translation;
  let ref = validRef(
    {
      book: code,
      chapter: +chapter,
      from: params.has("from") ? +params.get("from") : null,
      to: params.has("to") ? +params.get("to") : null,
      translation: tr,
    },
    ui.refs,
  );
  const b = await getBook(ref.book, tr);
  if (ui.token !== token) return;
  const vs = b.chapters[ref.chapter - 1];
  const origin = params.get("origin") || "",
    ctx = contextOf(origin);
  ui.reader = { ref, book: b, vs, origin, context: ctx };
  ui.selection = new Set();
  if (!store.error)
    try {
      change((d) => {
        d.reading = { ...ref };
        const last = d.events.find((x) => x.kind === "reading");
        if (
          !last ||
          last.ref?.book !== code ||
          last.ref?.chapter !== +chapter ||
          Date.now() - time(last.at) > 86400000
        )
          d.events.unshift({
            id: id(),
            kind: "reading",
            at: now(),
            text: refLabel(ref),
            ref,
            route: readRoute(ref),
          });
      });
    } catch (err) {
      notify(err.message, true);
    }
  shell(
    `<div class="reader-top">${back(origin ? "Zurück" : "Bibel", origin ? origin.split("/").slice(0, 2).join("/") : "bible")}<label class="sr-only" for="translation">Übersetzung</label><select id="translation" data-change="translation">${Object.entries(
      TRANSLATIONS,
    )
      .map(
        ([k, v]) =>
          `<option value="${k}" ${k === tr ? "selected" : ""}>${e(v.label)}</option>`,
      )
      .join(
        "",
      )}</select>${readingTools()}</div><div class="reader-selectors"><div><label for="reader-book">Buch</label><select id="reader-book" data-change="reader-book">${ui.books.map((x) => `<option value="${x.code}" ${x.code === code ? "selected" : ""}>${e(x.name)}</option>`).join("")}</select></div><div><label for="reader-chapter">Kapitel</label><select id="reader-chapter" data-change="reader-chapter">${b.chapters.map((_, i) => `<option value="${i + 1}" ${i + 1 === +chapter ? "selected" : ""}>${i + 1}</option>`).join("")}</select></div></div>
 ${heading(ctx ? "Lesen & verstehen" : "Bibel", b.name + " " + ref.chapter)}${ctx ? `<aside class="context"><span class="overline">Im Zusammenhang</span><p>${e(ctx.context)}</p><span class="meta">Im Fokus: ${e(refLabel(ref))}. Das ganze Kapitel bleibt lesbar.</span>${ref.from ? button("Zum Abschnitt", "focus-passage", {}, "text-button") : ""}</aside>` : ""}<aside class="reader-reflection-entry" aria-label="Deinen Gedanken festhalten"><span>Etwas bleibt bei dir?</span>${button("Gedanken festhalten", "reflect-reader", {}, "text-button")}</aside><div class="reading-text" id="verses">${renderReaderFlow(vs,v=>readerVerse(v,ref))}<span id="chapter-end-sentinel" aria-hidden="true"></span></div>
 <section class="short-chapter-confirm" hidden><p>Wenn du dieses kurze Kapitel gelesen hast, kannst du es als Teil deiner Bibelreise festhalten.</p>${button("Kapitel als erkundet festhalten","explore-chapter",{},"button quiet")}</section>${journeyAcknowledgement(s(),ui.books,ref)}${readerChapterQuestions(ref, origin)}${chapterNavigation({previous:ref.chapter>1?readRoute({book:code,chapter:ref.chapter-1,translation:tr},origin):null,next:ref.chapter<b.chapters.length?readRoute({book:code,chapter:ref.chapter+1,translation:tr},origin):null})}
 <section class="reflection-invite"><span class="overline">Was bleibt bei dir?</span><h2>${e(ctx?.question || "Was berührt dich in diesem Text?")}</h2><p>Ein Satz genügt. Du kannst daraus später einen Weg machen.</p>${button("Meinen Gedanken festhalten", "reflect-reader", {}, "button primary")}</section><small class="translation-credit">${e(TRANSLATIONS[tr].name)} · ${tr === "otb" ? "CC BY-SA 4.0" : "gemeinfrei"} · ${link("Textquelle", "licenses")}</small><div id="selection-bar"></div>`,
    "bible",
    "reader-page",
  );
  const end=$("#chapter-end-sentinel").getBoundingClientRect();
  const topbarBottom=$(".topbar").getBoundingClientRect().bottom;
  const openingBottom=chapterOpeningBottom({nav:$(".primary-nav").getBoundingClientRect(),topbarBottom,viewportWidth:window.innerWidth,viewportHeight:window.innerHeight});
  ui.reader.needsConfirmation=initiallyVisibleChapterEnd({top:end.top,bottom:end.bottom,scrollY:window.scrollY,topbarBottom,navTop:openingBottom});
  const alreadyExplored=!$(".journey-acknowledgement").hidden;
  $(".short-chapter-confirm").hidden=!ui.reader.needsConfirmation||alreadyExplored;
  ui.journeyStop=observeChapterEnd({sentinel:$("#chapter-end-sentinel"),topbar:$(".topbar"),nav:$(".primary-nav"),isCurrent:()=>ui.token===token,isBlocked:()=>ui.reader.needsConfirmation||$("#dialog").open||ui.selection.size>0||$("#menu-toggle")?.getAttribute("aria-expanded")==="true",onReached:acknowledgeReaderChapter});
}
// A focus/font layout change is not evidence that a newly exposed ending was read.
window.addEventListener('faithpath-reader-layout',()=>{
 const sentinel=$('#chapter-end-sentinel');if(!sentinel||!ui.reader)return;
 const box=sentinel.getBoundingClientRect(),topbarBottom=$('.topbar').getBoundingClientRect().bottom;
 const navTop=chapterOpeningBottom({nav:$('.primary-nav').getBoundingClientRect(),topbarBottom,viewportWidth:innerWidth,viewportHeight:innerHeight});
 if(!$('.journey-acknowledgement').hidden)return;
 if(box.top>=topbarBottom&&box.bottom<=navTop){ui.reader.needsConfirmation=true;$('.short-chapter-confirm').hidden=false;}
});
// One persistence path for automatic long-chapter endings and deliberate short-chapter consent.
function acknowledgeReaderChapter() {
  if(!ui.reader||!$(".reader-page"))return;
  try {
    change(data=>recordExploredChapter(data,ui.reader.ref,ui.books,now(),id()));
    const ack=$(".journey-acknowledgement");if(ack)ack.hidden=false;
    const confirmation=$(".short-chapter-confirm");if(confirmation)confirmation.hidden=true;
    ui.reader.needsConfirmation=false;
    ui.journeyStop?.();ui.journeyStop=null;
  } catch(error){notify(error.message,true);}
}
function readerChapterQuestions(ref, origin) {
  const unit = chapterUnit(ui.chapterCatalog, ref.book, ref.chapter);
  if (!unit) return "";
  return chapterOffer({unit,done:!!s().quiz[unit.id]?.done,quizRoute:chapterQuizRoute(unit,readRoute(ref,origin))});
}
function chapterCollection(bookCode) {
  const code = bookCode ? normBook(bookCode) : "";
  const book = ui.books.find(book => book.code === code);
  const units = code ? ui.chapterCatalog.byBook.get(code) : null;
  if (code && (!book || !units)) return notFound();
  const collectionRow = (title, sub, route, data) => row(title, sub, route).replace('<a ', `<a ${data} `);
  const rows = code ? units.map(unit => collectionRow(`Kapitel ${unit.chapter + 1}`, `${unit.questions.length} Fragen${s().quiz[unit.id]?.done ? " · angesehen" : ""}`, chapterQuizRoute(unit, `chapter-quizzes/${code}`), `data-chapter-unit="${unit.id}"`)).join("") : ui.books.filter(book => ui.chapterCatalog.byBook.has(book.code)).map(book => {
    const units = ui.chapterCatalog.byBook.get(book.code), count = units.reduce((n, unit) => n + unit.questions.length, 0);
    return collectionRow(book.name, `${units.length} Kapitel`, `chapter-quizzes/${book.code}`, `data-chapter-book="${book.code}" data-chapters="${units.length}" data-questions="${count}"`);
  }).join("");
  shell(`${back(code ? "Kapitelfragen" : "Entdecken", code ? "chapter-quizzes" : "discover")}${heading("Kapitelfragen", code ? book.name : "Buch für Buch verstehen.", code ? "Fragen zum gelesenen Kapitel. In deinem Tempo." : "Wähle ein Buch und dann ein Kapitel.")}<div class="chapter-quiz-collection">${rows}</div>`, "bible", "chapter-questions-page depth-page");
}
function chapterQuizComplete(unit, navigation) {
  const amount = unit.questions.length === 5 ? "fünf" : unit.questions.length;
  shell(`${back("Zurück", navigation.backRoute)}<section class="chapter-quiz-complete">${heading("Kapitelfragen abgeschlossen", `Fragen zu ${unit.ref}`, `Du hast die ${amount} Fragen zu ${unit.ref} angesehen.`)}<div class="chapter-questions-actions">${link("Zurück zum Kapitel", navigation.readerRoute, "button primary")}${navigation.nextReaderRoute ? link("Nächstes Kapitel lesen", navigation.nextReaderRoute, "button quiet") : ""}${link("Zur Sammlung", navigation.collectionRoute, "text-link")}</div>${button("Gedanken festhalten", "reflect-story", {id:unit.id}, "text-button")}</section>`, "bible", "chapter-questions-page depth-page");
}
function selection() {
  const a = [...ui.selection].sort((a, b) => a - b);
  if (!a.length) return null;
  if (a.some((n, i) => i && n !== a[i - 1] + 1))
    throw new Error("Bitte wähle zusammenhängende Verse aus.");
  return { ...ui.reader.ref, from: a[0], to: a.at(-1), label: "" };
}
function selectionBar() {
  const container = $("#selection-bar");
  if (!container) return;
  $$(".verse").forEach((el) => {
    el.setAttribute("aria-pressed", String(ui.selection.has(+el.dataset.v)));
  });
  document.body.classList.toggle("has-verse-selection",ui.selection.size>0);
  container.innerHTML = ui.selection.size
    ? `<div class="selection-bar" role="region" aria-label="Versaktionen"><span>${ui.selection.size} ${ui.selection.size === 1 ? "Vers" : "Verse"} ausgewählt</span><div>${button("Markieren", "mark", {}, "select-action")}${button("Notiz", "reflect-reader", {}, "select-action")}${button("Mit Weg verbinden", "connect-reader", {}, "select-action")}${button("Kopieren", "copy", {}, "select-action")}${button(icon("close") + '<span class="sr-only">Auswahl aufheben</span>', "clear-selection", {}, "icon-button")}</div></div>`
    : "";
}
function currentRef() {
  const ref = selection() || ui.reader.ref;
  return { ...ref, label: refLabel(ref) };
}
function scriptureNote(h, detail = false) {
  const notes = markNotes(h), paths = markPaths(h),context=highlightContext(s(),h);
  return `<article class="scripture-note highlight-${highlightColor(h)}"><div class="note-meta"><span class="color-label">${e(HIGHLIGHT_COLORS[highlightColor(h)])}</span><time>${date(h.at)}</time></div><h2>${link(e(refLabel(h)), readRoute(h,"marks"), "scripture-reference")}</h2><blockquote>${e(h.snippet || "")}</blockquote>${detail ? notes.map(j => `<p class="personal-note">${link(e(j.text), j.route)}</p>`).join("") : ""}${context.paths.length || context.notes.length || context.review ? '<div class="mark-continuity">' : ""}${detail ? paths.map(p=>`<p>Teil von: ${link(e(p.title),"path/"+encodeURIComponent(p.id))}</p>`).join("") : context.paths[0] ? `<p>Teil von: ${link(e(context.paths[0].title),"path/"+encodeURIComponent(context.paths[0].id))}</p>` : ""}${context.notes[0] || context.review ? `<p>${context.notes[0] ? link("Gedanke vorhanden",context.notes[0].route) : ""}${context.notes[0] && context.review ? " · " : ""}${context.review ? link("Später reflektiert",context.review.route) : ""}</p>` : ""}${context.paths.length || context.notes.length || context.review ? "</div>" : ""}${!detail ? '<details class="note-edit"><summary>Stelle bearbeiten</summary>' : ""}<div class="note-actions">${button("Farbe ändern","highlight-color",{id:h.id},"text-button")}${button(notes.length ? "Notiz bearbeiten" : "Notiz hinzufügen","highlight-note",{id:h.id},"text-button")}${button("Mit Weg verbinden","connect-ref",{ref:JSON.stringify(h)},"text-button")}${button("Markierung entfernen","remove-mark",{id:h.id},"text-button danger-text")}</div>${!detail ? "</details>" : ""}${!detail ? link("Stelle ansehen","mark/"+encodeURIComponent(h.id),"text-link") : ""}</article>`;
}
function marks() {
  const all = s().highlights, data = all.filter(h => (!ui.markColor || highlightColor(h) === ui.markColor) && (!ui.markBook || normBook(h.book) === ui.markBook) && (!ui.markContext || (ui.markContext === "note" ? markNotes(h).length : markPaths(h).length)));
  shell(`${heading("Deine Bibel", "Markierungen", "Stellen, die Teil deiner Geschichte geworden sind.")}<div class="segmented">${link("Lesen","bible")}${link("Entdecken","discover")}${link("Markierungen","marks","active")}</div>${all.length ? `<details class="mark-filters" ${ui.markColor || ui.markBook || ui.markContext ? "open" : ""}><summary>Markierungen filtern · ${data.length}</summary>${select("Farbe","mark-color",[["","Alle Farben"],...Object.entries(HIGHLIGHT_COLORS)],ui.markColor).replace('name="mark-color"','name="mark-color" data-change="mark-color"')}${select("Buch","mark-book",[["","Alle Bücher"],...ui.books.filter(b=>all.some(h=>normBook(h.book)===b.code)).map(b=>[b.code,b.name])],ui.markBook).replace('name="mark-book"','name="mark-book" data-change="mark-book"')}${select("Verbindung","mark-context",[["","Alle"],["note","Mit Notiz"],["path","Mit Weg verbunden"]],ui.markContext).replace('name="mark-context"','name="mark-context" data-change="mark-context"')}</details>` : ""}${data.length ? `<div class="scripture-notes">${data.slice().sort((a,b)=>time(b.at)-time(a.at)).map(h=>scriptureNote(h)).join("")}</div>` : empty(all.length ? "Keine Stelle für diesen Filter." : "Was dich anspricht, darf bleiben.",all.length ? "Wähle eine andere Farbe, ein Buch oder eine Verbindung." : "Ein Vers, ein Gedanke, eine persönliche Verbindung.",all.length ? button("Alle Markierungen","reset-mark-filters",{},"button primary") : link("Bibel öffnen","bible","button primary"))}`,"bible","marks-page depth-page");
}
function markDetail(id) {
  const h = s().highlights.find(h=>h.id===id); if (!h) return notFound();
  shell(`${back("Markierungen","marks")}${heading("Deine Bibel",refLabel(h))}${scriptureNote(h,true)}`,"bible","marks-page depth-page");
}
function discoverySelection() {
 return selectDiscovery(ui.discoveryIndex,{query:ui.storySearch,book:ui.storyBook,kind:ui.storyKind,limit:ui.storyLimit});
}
function discover(legacyQuiz=false) {
 ui.discoveryLegacy=legacyQuiz;
 shell(renderDiscovery({model:discoverySelection(),books:ui.books.filter(b=>ui.discoveryBooks.has(b.code)),filters:{query:ui.storySearch,book:ui.storyBook,kind:ui.storyKind},editorial:runtimeModel.flow.stories.slice(0,3),legacyQuiz},{heading,link,button}),"bible","discover-page discovery-phase4 depth-page");
}
function quizIndex(){discover(true);}
function refreshDiscovery({focusNew=false,previousCount=0}={}) {
 const target=$("#story-results");if(!target)return;
 const model=discoverySelection();
 const curated=$(".discovery-curation");if(curated)curated.hidden=model.filtered;target.innerHTML=renderDiscoveryResults(model,{button},ui.discoveryLegacy);
 $("#discovery-count").textContent=discoveryCount(model);
 const editorial=$(".discover-editorial");if(editorial)editorial.hidden=model.filtered;
 if(focusNew)$(".discovery-result-list")?.children[previousCount]?.focus();
}
function statusFor(x) {
  return x.verification?.status === "verse-checked"
    ? "Vorhandener Prüfvermerk: gegen Luther 1912 geprüft"
    : x.kind === "chapter-quiz"
      ? (x.questions.every(q=>runtimeModel.index.question_index.find(row=>row.faithpath_id===q.faithpath_id)?.final_qa_status==="APPROVED") ? "Im redaktionell freigegebenen NT-Finalmaster geprüft" : "Textbasierte Übung · redaktionell noch zu prüfen")
      : "Bestandsinhalt · Prüfvermerk fehlt";
}
function story(id) {
  const x = ui.stories.find((x) => String(x.id) === id);
  if (!x) return notFound();
  const canonical=canonicalStoryForLegacy(x);
  if(canonical)return mergedStory(canonical.story_id);
  const ref = validRef(
    {
      book: x.book,
      chapter: x.chapter + 1,
      from: x.from,
      to: x.to,
      translation: x.kind === "chapter-quiz" ? "l1912" : s().translation,
      label: x.ref,
    },
    ui.refs,
  );
  shell(
    `${back("Entdecken", "discover")}${heading(x.ref, x.title, x.desc)}<p class="content-note">${e(statusFor(x))}</p>${s().quiz[x.id]?.done ? `<p class="meta">Fragen angesehen am ${date(s().quiz[x.id].done)}.</p>` : ""}<div class="actions">${link("Abschnitt lesen", readRoute(ref, "story/" + x.id), "button primary")}${button("Verständnisfragen", "quiz", { id: x.id }, "button quiet")}</div><section class="reflection-invite"><span class="overline">Deine Reflexion</span><h2>${e(x.reflection)}</h2>${button("Gedanken festhalten", "reflect-story", { id: x.id }, "button primary")}<p class="meta">Deine Reflexion wird nicht bewertet.</p></section>`,
    "bible",
  );
}
function quiz() {
  const { story: x, index, answer, navigation } = ui.quiz,
    q = x.questions[index];
  shell(
    `${back(navigation?.backRoute.startsWith("read/") ? "Zurück zum Kapitel" : navigation?.backRoute.startsWith("chapter-quizzes/") ? "Zur Kapitelliste" : "Zur Geschichte", navigation?.backRoute || "story/" + x.id)}<div class="quiz-head"><span class="overline">${x.kind === "chapter-quiz" ? "Fragen zu diesem Kapitel" : "Verständnisfragen"}</span><span>Frage ${index + 1} von ${x.questions.length}</span></div><h1 class="quiz-title" tabindex="-1" data-question-id="${e(q.faithpath_id)}">${e(q.q)}</h1><p class="meta">${e(x.ref)}${x.kind === "chapter-quiz" ? " · Grundlage: Luther 1912" : ""}</p><div class="answers">${q.a.map((a, i) => `<button type="button" data-action="answer" data-answer="${i}" ${answer != null ? "disabled" : ""} class="answer ${answer != null && i === q.c ? "correct" : answer === i ? "selected-wrong" : ""}"><span>${String.fromCharCode(65 + i)}</span><span>${e(a)}${answer != null && i === q.c ? "<small>Richtige Antwort</small>" : answer === i ? "<small>Deine Antwort</small>" : ""}</span></button>`).join("")}</div>${answer != null ? `<section class="explanation" role="status" tabindex="-1"><strong>${answer === q.c ? "Ja, das steht im Text." : "Schau noch einmal auf den Zusammenhang."}</strong><p>${e(q.x)}</p><span class="meta">${e(q.ref || q.p)}</span></section>${button(index === x.questions.length - 1 ? "Kapitel abschließen" : "Nächste Frage", "next-question", {}, "button primary")}` : ""}`,
    "bible",
  );
}
function paths() {
  shell(renderPathsOverview(selectPathsOverview(s(),{archived:ui.archive}),{heading,button,row,date,treePreview:`<a class="personal-tree-ribbon" href="#tree">${renderOliveTree(treeLevel(s()),{context:'paths',decorative:true})}<span><strong>Was in deinem Leben Wurzeln schlägt.</strong><span>Deinen Olivenbaum ansehen →</span></span></a>`}),"paths","paths-page depth-page");
}
function path(pid) {
  const model=selectPathDetail(s(),pid,{limit:ui.historyLimit});if(!model)return notFound();
  const renderToken=ui.token;
  shell(renderPathDetail(model,{back,heading,button,link,date,refLabel,readRoute:ref=>readRoute(ref,"path/"+pid),timelineHTML,categoryLabel:category(model.path.category).label,facts:pathFacts(s(),pid)}),"paths","path-page depth-page");
  for (const quote of $$("[data-path-quote]")) {
    if (quote.textContent) continue;
    const ref=JSON.parse(quote.dataset.pathQuote);
    getBook(normBook(ref.book),ref.translation || s().translation).then(book=>{
      if(ui.token!==renderToken || !quote.isConnected)return;
      const words=book.chapters[+ref.chapter-1].filter(v=>!ref.from || (v[0]>=ref.from && v[0]<=(ref.to || ref.from))).slice(0,3).map(v=>v[1]).join(" ");
      quote.textContent=words.length>340 ? words.slice(0,340)+" …" : words;
    }).catch(()=>{ if(quote.isConnected)quote.remove(); });
  }
}
function tree() {
  const model=selectTreeHistory(s());
  shell(renderTreeJourney(model,{back,heading,link,date,stageName:stageNames[model.stage],branchMarkup:treeBranchView(s(),model.stage)}),"paths","tree-page");
}
function journalModel(){return selectJournal(s(),{query:ui.search,filter:ui.filter,limit:ui.journalLimit,books:ui.books});}
function journal() {
 const model=journalModel();shell(renderJournal(model,{heading,button,results:journalResults(model)}),"journal","journal-page depth-page editorial-page");
}
function journalResults(model=journalModel()) {
 return renderJournalResults(model,{button,link,date,refLabel,readRoute,validReference:ref=>{try{validRef(ref,ui.refs);return true;}catch{return false;}}});
}
function refreshJournal(){
 const model=journalModel();
 $("#journal-results").innerHTML=journalResults(model);
 $("#journal-count").textContent=journalCount(model);
 const reset=$(".journal-tools .journal-reset");if(reset)reset.hidden=!model.query&&model.filter==="Alle";
 const summary=$(".journal-tools summary");
 if(summary)summary.textContent="Filter"+(model.filter!=="Alle"?" · "+model.filter:"");
 $$("[data-action=journal-filter]").forEach(el=>{const active=el.dataset.filter===model.filter;el.classList.toggle("active",active);el.setAttribute("aria-pressed",String(active));});
}
function entry(id, kind = "entry") {
  const x=(kind === "reflection"?s().reflections:kind === "review"?allReviews(s()):s().journal).find(j=>j.id===id);if(!x)return notFound();
  if(kind==="review"){const path=s().paths.find(p=>p.id===x.pathId);shell(renderReviewDetail(x,reviewSourceContext(s(),x),{back,link,date,path}),"paths","journal-detail editorial-page path-page path-review-page");return;}
  const later=reviewsFor(s(),x,kind === "reflection"?"reflection":"journal")[0],previous=ui.continuitySaved===x.id?previousThought(s(),x):null;
  const ownPath=kind==="review"&&x.pathId&&s().paths.find(p=>p.id===x.pathId);
  shell(`${ownPath?back("Zum Weg","path/"+encodeURIComponent(ownPath.id)):back("Journal","journal")}<header class="entry-heading"><div><span class="overline">${e(x.subtype||x.type||(kind === "review"?"Rückblick":"Reflexion"))}</span><h1 tabindex="-1">${date(x.date)}</h1></div>${kind === "entry" ? `<details class="entry-options"><summary aria-label="Journaleintrag verwalten">${icon("more")}<span class="sr-only">Journaleintrag verwalten</span></summary><div class="entry-context-menu">${button("Bearbeiten","edit-entry",{id},"text-button")}${button("Weg verbinden / ändern","journal-path",{id},"text-button")}${isBibleNote(x)?button("Notiz an der Bibelstelle entfernen","delete-note",{id,kind:"journal"},"text-button danger-text"):""}${button("Journaleintrag löschen","delete-journal",{id},"text-button danger-text")}</div></details>` : ""}</header>${kind==="review"?renderReviewSource(reviewSourceContext(s(),x),{link,date}):""}<div class="entry-text preserve">${e(x.text)}</div><div class="entry-connections">${(x.pathIds||[]).map(pid=>{const p=s().paths.find(p=>p.id===pid);return p?`<p>Teil deines Weges: ${link(e(p.title),"path/"+encodeURIComponent(pid))}</p>`:"";}).join("")}${x.ref?`<p>Verbunden mit ${link(e(refLabel(x.ref)),readRoute(x.ref,"journal"))}</p>`:""}${later?`<p>Später darauf zurückgeblickt · ${link("Rückblick ansehen",later.route)}</p>`:""}</div>${previous?`<aside class="continuity-strip previous-thought-prompt"><p>Dazu hast du schon einmal etwas festgehalten.</p>${link("Früheren Gedanken ansehen",previous.route,"text-link")}</aside>`:""}${kind === "reflection"&&isBibleNote(x)?button("Notiz bearbeiten","edit-note",{id,kind:"reflection"},"button quiet"):""}${kind === "reflection"&&isBibleNote(x)?`<div class="note-delete-row">${button("Notiz an der Bibelstelle entfernen","delete-note",{id,kind:"reflection"},"text-button danger-text")}</div>`:""}`,"journal","journal-detail editorial-page"+(kind==="review"?" path-page path-review-page":""));
}
function storyTimeline(items,limit) {
  const groups=new Map();for(const x of items.slice(0,limit)) {const d=new Date(x.at),key=d.toLocaleDateString("de-DE",{month:"long",year:"numeric"});if(!groups.has(key))groups.set(key,[]);groups.get(key).push(x);}
  return [...groups].map(([month,moments])=>`<section class="story-month"><h2 class="overline">${e(month)}</h2>${timelineHTML(moments,limit)}</section>`).join("");
}
function reflectionPairs() {
  return continuityGroupsHTML(reviewPairs(s()),2);
}
function history() {
  const items = timeline(s());
  shell(
    `${back("Heute", "today")}${heading("Deine Glaubensgeschichte", "Damals wichtig. Heute Teil von dir.", "Bibelstellen, Gedanken, Wege und Rückblicke — in ihrem Zusammenhang.")}<div class="segmented">${link("Meine Geschichte", "history", "active")}${link("Rückblicke", "reviews")}</div>${reflectionPairs()}${items.length ? (reviewPairs(s()).length ? `<details class="history-moments"${ui.historyExpanded ? " open" : ""}><summary>Alle Momente deiner Geschichte</summary>${storyTimeline(items,ui.historyLimit)}</details>` : storyTimeline(items,ui.historyLimit)) : empty("Deine Geschichte beginnt mit einem Moment.", "Wenn du einen Gedanken oder eine Entwicklung festhältst, findest du ihn hier wieder.", link("Einen Anfang finden", "guidance", "button primary"))}${items.length > ui.historyLimit ? button("Weitere Momente", "more-history", {}, "button quiet") : ""}`,
    "paths", "history-page depth-page",
  );
}
function reviews() {
 const model=selectReviews(s(),{limit:ui.reviewsLimit});
 shell(`${back("Heute","today")}${heading("Rückblicke","Was ist daraus geworden?","Ein früherer Gedanke und das, was du später dazu festhältst. Ohne Bewertung.")}<div class="segmented">${link("Meine Geschichte","history")}${link("Rückblicke","reviews","active")}</div>${renderPendingReviews(model.pending,{date,button,link})}${renderCompletedReviews(model,{link,date,button})}${renderReminderControls(selectReminderControls(s()),{date,button})}`,"paths","reviews-page depth-page");
}
function more() {
  const section=new URLSearchParams(location.hash.split("?")[1]||"").get("section");
  if(section === "data")return shell(renderBackupPage({back,heading,button,summary:store.error?null:backupSummary(s()),canUndo:!store.error&&!!deviceStorage.getItem(KEYS.restore)}),"more","settings-page utility-page backup-page");
  if(section === "settings")return shell(`${back("Mehr","more")}${heading("Einstellungen & Daten","Einstellungen")}${themePicker(s())}<section class="section"><h2>Offline & auf dem iPhone</h2><p id="offline-state" role="status">${ui.offline ? "Beide Bibeln und die App sind für dieses Gerät offline bereit." : "Offline-Vorbereitung läuft, solange diese Seite online geöffnet ist."}</p>${button("Offline-Status prüfen", "offline-check", {}, "text-button")}<p>Auf dem iPhone: In Safari „Teilen“ öffnen, dann „Zum Home-Bildschirm“ wählen. Zum ersten Einrichten online bleiben, bis oben „offline bereit“ steht.</p></section><section class="section"><h2>Privat auf deinem Gerät</h2><p>Keine Werbung, keine Tracking-SDKs, kein KI-Chat. Persönliche Texte werden nicht an FaithPath übertragen. Sie sind lokal gespeichert und nicht zusätzlich verschlüsselt. Der Hosting-Anbieter verarbeitet beim Laden technische Verbindungsdaten.</p>${link("Bibeltexte & Lizenzen", "licenses")}${button("Einführung ansehen", "onboard", {}, "text-button")}</section><div class="list">${row("Bibeltexte & Lizenzen","","licenses")}${row("Inhalte & Prüfstatus","","content-status")}</div><small class="build-id">FaithPath V4 · ${BUILD}</small>`,"more","settings-page utility-page");
  shell(renderMore({heading,row,button}),"more","more-page navigation-more");
}
function contentStatus() {
  shell(`${back("Mehr","more")}${heading("Transparent bleiben","Inhalte & Prüfstatus","Ein technischer Referenztest ist keine theologische Qualitätsprüfung.")}<dl class="status-list"><div><dt>Bibeltexte offline</dt><dd>OTB Deutsch und Luther 1912, je 66 Bücher.</dd></div><div><dt>Geschichten</dt><dd>436 gemeinsame Geschichten · 2.314 Nachlese-Fragen und 260 FaithPath-Storyfragen · 2.479 Fragen im geprüften gemeinsamen Ablauf.</dd></div><div><dt>Kapitelübungen</dt><dd>260 Kapitelübungen / 1.300 Fragen bleiben ein eigener Bestand.</dd></div><div><dt>Dokumentierte Freigabe</dt><dd>FP-0261 bis FP-1560: 1.300 NT-Kapitelfragen aus dem redaktionell freigegebenen Finalmaster. Für FP-0001 bis FP-0260 bleibt die vorhandene Katalogfreigabe vom 30.09.2026 bestehen.</dd></div><div><dt>Umfang des Nachweises</dt><dd>Die vorhandene Katalogfreigabe bleibt erhalten. Alle 2.314 Nachlese-Fragen besitzen vier Antwortoptionen. In dieser Überarbeitung wurden 56 Ergänzungen, 150 markierte Bestandsfragen und zwei Verszuordnungen anhand beider lokalen Übersetzungen geprüft. Nachweisbare Quellfehler wurden berichtigt; Geschichten, Zuordnungen und persönliche Reflexionen bleiben erhalten.</dd></div><div><dt>Gemeinsamer Ablauf</dt><dd>Die bestehende geprüfte Zuordnung und Dublettenregel bleiben unverändert. Nachlese-Fragen mit geprüften Antwortoptionen werden ebenfalls zur Auswahl angeboten. Die Einzelentscheidungen und der Prüfungsumfang sind im zugehörigen Redaktionsbericht dokumentiert.</dd></div></dl>`,"more");
}
function licenses() {
  shell(
    `${back("Mehr", "more")}${heading("Textquellen", "Bibeltexte & Lizenzen")}<section class="section"><h2>Open Translation Bible Deutsch</h2><p>Quelle: OpenTranslationBible / open-bible. Creative Commons Attribution-ShareAlike 4.0 International. Der mitgelieferte Text bleibt unverändert.</p><a href="https://github.com/OpenTranslationBible/open-bible">Quellprojekt</a> · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a></section><section class="section"><h2>Lutherbibel 1912</h2><p>Gemeinfreier Text. Im Ausgangsprojekt von eBible.org (deu1912) bezogen. Unverändert erhalten.</p><a href="https://ebible.org/deu1912/">Textquelle</a></section><section class="section"><h2>Schriften & Gestaltung</h2><p>Newsreader und DM Sans werden lokal mitgeliefert und unter der SIL Open Font License genutzt. Es werden keine externen Schriftdienste geladen.</p><a href="${new URL('./verbunden/assets/licenses/newsreader-OFL.txt',import.meta.url).href}">Newsreader-Lizenz</a> · <a href="${new URL('./verbunden/assets/licenses/dmsans-OFL.txt',import.meta.url).href}">DM-Sans-Lizenz</a></section>`,
    "more",
  );
}
function notFound() {
  shell(
    `${heading("Nicht gefunden", "Dieser Moment ist nicht verfügbar.", "Vielleicht wurde der Eintrag entfernt oder die Adresse ist unvollständig.")}${link("Zur Startseite", "today", "button primary")}`,
  );
}

const input = (label, name, value = "", placeholder = "", type = "text") =>
  `<div class="field"><label for="f-${name}">${e(label)}</label><input id="f-${name}" name="${name}" type="${type}" value="${e(value)}" placeholder="${e(placeholder)}"></div>`;
const textarea = (label, name, value = "", placeholder = "") =>
  `<div class="field"><label for="f-${name}">${e(label)}</label><textarea id="f-${name}" name="${name}" rows="5" placeholder="${e(placeholder)}">${e(value)}</textarea></div>`;
const select = (label, name, opts, value = "") =>
  `<div class="field"><label for="f-${name}">${e(label)}</label><select id="f-${name}" name="${name}">${opts.map(([v, t]) => `<option value="${e(v)}" ${String(v) === String(value) ? "selected" : ""}>${e(t)}</option>`).join("")}</select></div>`;
const pathOptions = () => [
  ["", "Noch keinem Weg zuordnen"],
  ...s()
    .paths.filter((p) => !p.archived)
    .map((p) => [p.id, p.title]),
];
function modal(title, content, form = null, values = null) {
  const d = $("#dialog");
  d.classList.remove("onboarding-dialog");
  d.classList.toggle("core-dialog", ["path", "step", "note", "entry"].includes(form?.type) || ["Markierung gestalten", "Markierung entfernen?", "Weg wirklich löschen?", "Notiz an der Bibelstelle entfernen?"].includes(title));
  ui.dialogRoute = location.hash.slice(1);
  ui.form = form;
  ui.draftSession = null;
  const writing=["entry","note","review"].includes(form?.type);
  d.classList.toggle("writing-dialog",writing);
  const dialogHeader=`<div class="dialog-top"><h2 id="dialog-title" aria-label="${e(title)}">${e(title).replace("Journaleintrag", "Journal<wbr>eintrag")}</h2><div class="dialog-header-actions">${button(icon("close") + '<span class="sr-only">Schließen</span>', "close", {}, "icon-button")}</div></div>`;
  d.innerHTML=writing ? writingDialog(content,dialogHeader) : dialogHeader+content;
  if (values)
    for (const [k, v] of Object.entries(values)) {
      const el = d.querySelector(`[name="${CSS.escape(k)}"]`);
      if (el) {
        if (el.type === "checkbox") el.checked = !!v;
        else el.value = v;
      }
    }
  if (!d.open) d.showModal();
  d.style.scrollPaddingTop=($(".dialog-top",d).getBoundingClientRect().height+32)+"px";
  document.body.classList.add("modal-open");
  if(writing)prepareWritingArea(d);
  // Focus once while opening; a later timer must not override keyboard navigation.
  const initialControl = $("input:not([type=checkbox]),textarea,select",d) || $(".color-choice[tabindex=\"0\"]",d) || $("button",d);
  initialControl?.focus();
  if (writing) initialControl?.scrollIntoView({block:"start",behavior:"instant"});
}
async function finishForm(draftSession = ui.draftSession) {
  try {
    await clearDraft(localStorage,draftSession);
  } catch { notify("Dein gespeicherter Gedanke ist erhalten. Der Entwurf konnte noch nicht entfernt werden.",true); }
  if(ui.draftSession!==draftSession)return;
  ui.form = null;
  ui.draftSession = null;
  $("#dialog").close();
  document.body.classList.remove("modal-open");
}
function closeModal() {
  backupController.invalidate();
  const journalFocus=ui.journalDeletion;
  ui.noteDeletion=null;
  ui.journalDeletion=null;
  ui.form = null;
  ui.draftSession = null;
  $("#dialog").close();
  document.body.classList.remove("modal-open");
  if(journalFocus)$(".entry-options summary")?.focus();
}
function snapshotForm() {
  const values = {};
  for (const el of $$("#dialog [name]"))
    values[el.name] = el.type === "checkbox" ? el.checked : el.value;
  return values;
}
async function persistDraft() {
  if (!ui.form) return;
  const form=ui.form,session=ui.draftSession,values=snapshotForm();
  try {
    if(journalRecoveryError||localStorage.getItem(JOURNAL_WRITE_KEY))throw new Error("Journal-Speichervorgang noch offen");
    if(!session)throw new Error("Dieser Entwurf konnte nicht sicher geöffnet werden.");
    await saveDraft(localStorage,session,{...form,values,saved:now()});
  } catch (error) {
    notify("Dein Entwurf kann gerade nicht zwischengespeichert werden. "+error.message, true);
  }
}
function openForm(type, args = {}, restored = null, draftRaw = undefined) {
  const existingDraft=localStorage.getItem(KEYS.draft);
  if(existingDraft!==null&&restored===null){
    ui.pendingForm={type,args,raw:existingDraft};
    modal("Ein Entwurf wartet auf dich",`<p>Du hast noch etwas Ungespeichertes. Möchtest du dort weiterschreiben?</p>${button("Entwurf fortsetzen","resume",{},"button primary full")}${button("Entwurf als Datei sichern","export-draft",{},"button quiet full")}${button("Entwurf verwerfen und neu beginnen","discard-and-open",{},"text-button")}`);
    return;
  }
  const draftSession=beginDraftSession(localStorage,restored!==null ? (draftRaw===undefined ? existingDraft : draftRaw) : null);
  let title = "",
    body = "",
    cta = "Speichern",
    values = {};
  if(type === "journal-path") {
    const old=s().journal.find(j=>j.id===args.id);if(!old)throw new Error("Dieser Eintrag ist nicht mehr vorhanden.");
    title="Weg verbinden / ändern";body=`<p class="meta">Die ausgewählte Zuordnung ersetzt die bisherigen Wegzuordnungen dieses Eintrags. Bibelstellen auf deinen Wegen bleiben erhalten.</p>`+select("Persönlicher Weg","pathId",[["","Noch keinem Weg zuordnen"],...s().paths.map(p=>[p.id,p.title+(p.archived?" · archiviert":"")])],old.pathIds?.[0]||"");
  }
  if(type === "note") {
    const old=s().reflections.find(x=>x.id===args.id);if(!isBibleNote(old)&&!old?.bibleNoteDeletedAt)throw new Error("Diese Bibelnotiz ist nicht mehr vorhanden.");
    title="Notiz bearbeiten";body=`<p class="meta">${e(refLabel(old.ref))}</p>${textarea("Dein Gedanke","text",old.text)}`;
  }
  if (type === "entry") {
    const old = args.id ? s().journal.find((j) => j.id === args.id) : null;
    values = {
      text: old?.text || "",
      kind: old?.subtype || old?.type || args.kind || "Gedanken",
      pathId: old?.pathIds?.[0] || args.pathId || "",
    };
    title = old
      ? "Gedanken bearbeiten"
      : args.ref
        ? "Was bleibt dir?"
        : "Dein Journal";
    body = `${args.ref ? `<p class="meta">${e(refLabel(args.ref))}</p>` : ""}${args.question ? `<p class="writing-prompt">${e(args.question)}</p>` : ""}${textarea("Dein Gedanke", "text", values.text, "Ein Satz kann ein Anfang sein …")}${select(
      "Art des Eintrags",
      "kind",
      [
        "Gedanken",
        "Bibel",
        "Reflexion",
        "Predigt",
        "Gebet",
        "Dankbarkeit",
        "Ziele",
      ].map((x) => [x, x]),
      values.kind,
    )}${select("Persönlicher Weg (optional)", "pathId", [...pathOptions(),...s().paths.filter(p=>p.archived&&p.id===(restored?.pathId??values.pathId)).map(p=>[p.id,p.title+" · archiviert"])], restored?.pathId??values.pathId)}${args.planId ? `<label class="checkbox-row"><input type="checkbox" name="planDone" checked> Diesen Abschnitt als festgehalten markieren</label>` : ""}`;
    cta = "Gedanken speichern";
  } else if (type === "path") {
    const old = args.id ? s().paths.find((p) => p.id === args.id) : null;
    title = old ? "Deinen Weg bearbeiten" : "Ein persönlicher Weg";
    body = `<p>Ein Weg begleitet ein Anliegen aus deinem Leben. Hier bleiben deine Bibelstellen, Gedanken, Gebete, kleinen Schritte und späteren Rückblicke zusammen. Beginne mit dem, was dich gerade beschäftigt.</p>${input("Name deines Weges", "title", old?.title || args.title || "", "Zum Beispiel: In Ruhe zuhören")}${select(
      "Bereich",
      "category",
      PATH_CATEGORIES.map((c) => [c.id, c.label]),
      old?.category || args.category || "sonstiges",
    )}${textarea("Warum ist dir das wichtig? (optional)", "why", old?.why || "")}${
      !old
        ? `${input("Ein kleiner Schritt (optional)", "step", "", "Zum Beispiel: Im nächsten Gespräch ausreden lassen")}${select(
            "Zum ersten Rückblick einladen",
            "days",
            [
              ["7", "In einer Woche"],
              ["21", "In drei Wochen"],
              ["42", "In sechs Wochen"],
            ],
            "21",
          )}`
        : ""
    }${old?.steps.find(x=>!x.done) ? textarea("Offener nächster Schritt", "currentStep", old.steps.find(x=>!x.done).text) : ""}`;
    cta = old ? "Änderungen speichern" : "Weg beginnen";
  } else if (type === "step") {
    const p = s().paths.find((p) => p.id === args.pathId);
    if (!p) return;
    const oldStep = args.stepId ? p.steps.find(x=>x.id===args.stepId && !x.done) : null;
    if (args.stepId && !oldStep) throw new Error("Bereits ausprobierte Schritte werden nicht überschrieben.");
    title = oldStep ? "Schritt bearbeiten" : "Ein kleiner nächster Schritt";
    const suggestions = category(p.category).steps.filter(
      (t) => !p.steps.some((x) => x.text === t),
    );
    body = `<p>Was wäre für „${e(p.title)}“ gerade machbar?</p>${suggestions.length ? `<details><summary>Ein paar Anregungen</summary><div class="suggestions">${suggestions.map((text) => button(e(text), "use-suggestion", { text }, "suggestion")).join("")}</div></details>` : ""}${textarea("Dein Schritt", "text", oldStep?.text || "", "Beschreibe eine konkrete, kleine Handlung.")}<p class="meta">Du probierst etwas aus. Ob daraus Entwicklung entsteht, hältst du später selbst fest.</p>`;
    cta = oldStep ? "Änderungen speichern" : "Schritt festhalten";
  } else if (type === "review") {
    const sourceSnapshot=capturePathReviewSource(s(),args,now());
    if(sourceSnapshot)args={...args,sourceSnapshot};
    const g = args.gap,
      p = args.pathId ? s().paths.find((p) => p.id === args.pathId) : null;
    title = "Was ist daraus geworden?";
    body = `<p class="writing-prompt">${e(g?.title || p?.title || "Dein früherer Gedanke")}</p>${g ? `<blockquote class="previous-thought">${e(args.sourceSnapshot?.text||g.detail)}</blockquote><p class="meta">Letzte Aktivität am ${date(g.at)}.</p>` : args.sourceSnapshot ? `<blockquote class="previous-thought">${e(args.sourceSnapshot.text)}</blockquote><p class="meta">Bezug für diesen Rückblick. Ein anderer Schritt wird dadurch nicht automatisch bewertet.</p>` : ""}${select(
      "Wo stehst du gerade?",
      "status",
      [
        ["thought", "Ich möchte einen Gedanken festhalten"],
        ["changed", "Etwas hat sich verändert"],
        ["working", "Ich arbeite noch daran"],
        ["unchanged", "Es hat sich nichts verändert"],
        ["notnow", "Im Moment nicht"],
      ],
      "thought",
    )}${textarea("Was möchtest du dazu festhalten?", "text", "", "Was war damals — und wie siehst du es heute?")}<label class="checkbox-row" id="confirm-development" hidden><input type="checkbox" name="development"> Das ist für mich eine echte Entwicklung.</label>${select(
      "Wann möchtest du wieder hinsehen?",
      "days",
      [
        ["0", "Vorerst nicht erinnern"],
        ["14", "In zwei Wochen"],
        ["42", "In sechs Wochen"],
      ],
      "0",
    )}<p class="meta">Alles darf so sein, wie es gerade ist. Dein bisheriger Weg bleibt bestehen. Erinnerungen erscheinen nur beim Nutzen der App; keine Push-Nachrichten.</p>`;
    cta = "Rückblick speichern";
  }
  if (!body) return;
  const existingNote=type === "entry" ? s().journal.find(x=>x.id===args.id) : type === "note" ? s().reflections.find(x=>x.id===args.id) : null;
  const deletion=isBibleNote(existingNote) ? `<div class="note-delete-row">${button("Notiz an der Bibelstelle entfernen","delete-note",{id:args.id,kind:type === "note" ? "reflection" : "journal"},"text-button danger-text")}</div>` : "";
  modal(
    title,
    `<form id="editor-form"><div id="form-error" role="alert" tabindex="-1"></div>${body}<button class="button primary full" type="submit">${cta}</button>${deletion}</form>`,
    { type, args },
    restored,
  );
  ui.draftSession=draftSession;
  if (type === "review") updateDevelopment();
}
function updateDevelopment() {
  const wrap = $("#confirm-development");
  if (wrap) {
    wrap.hidden = $("[name=status]", $("#dialog"))?.value !== "changed";
    if (wrap.hidden) $("[name=development]", $("#dialog")).checked = false;
  }
}
function connectSheet(args) {
  const ps = s().paths.filter((p) => !p.archived);
  modal(
    "Soll daraus ein Weg werden?",
    `<p>Verbinde diesen Gedanken mit etwas, das dich weiter begleitet.</p><div class="list">${ps.map((p) => button(`<span><strong>${e(p.title)}</strong></span>${icon("arrow")}`, "attach", { path: p.id, args: JSON.stringify(args) }, "list-row")).join("")}</div>${button("Einen neuen Weg beginnen", "path-from", { args: JSON.stringify(args) }, "button primary full")}${button("Für jetzt reicht der Gedanke", "close", {}, "text-button full")}`,
  );
}
function addRef(data, pathId, ref) {
  const p = data.paths.find((p) => p.id === pathId);
  if (!p) throw new Error("Dieser Weg ist nicht mehr vorhanden.");
  if (!p.links.some((l) => sameRef(l.ref, ref)))
    p.links.push({
      id: id(),
      kind: "verse",
      label: refLabel(ref),
      ref,
      date: now(),
    });
}
async function submitForm() {
  if (!ui.form) return;
  const draftSession=ui.draftSession;
  const { type, args } = ui.form,
    v = snapshotForm(),
    at = now();
  if(type === "journal-path") {
    change(data=>setJournalPath(data,args.id,v.pathId));await finishForm(draftSession);go("entry/"+encodeURIComponent(args.id));notify(v.pathId?"Mit deinem Weg verbunden":"Wegzuordnung entfernt");return;
  }
  if(type === "note") {
    const text=v.text.trim();if(!text)throw new Error("Schreibe einen Gedanken, bevor du ihn speicherst.");
    await journalTransaction(store,localStorage,data=>{const r=data.reflections.find(x=>x.id===args.id);if(!isBibleNote(r)&&!r?.bibleNoteDeletedAt)throw new Error("Diese Notiz wurde inzwischen entfernt.");
      const j=data.journal.find(j=>j.reflectionId===r.id&&sameRef(j.ref,r.ref)&&j.text===r.text);r.text=text;r.updatedAt=at;if(j){j.text=text;j.updatedAt=at;}},(_,raw)=>completedDraft(draftSession,raw));
    await finishForm(draftSession);go("reflection/"+encodeURIComponent(args.id));notify("Deine Notiz ist gespeichert.");return;
  }
  if (type === "entry") {
    const text = v.text.trim();
    if (!text)
      throw new Error("Schreibe einen Gedanken, bevor du ihn speicherst.");
    const jid = args.id || id(),
      rid = id();
    let chosen = v.pathId;
    await journalTransaction(store,localStorage,(d) => {
      const old = args.id ? d.journal.find((j) => j.id === args.id) : null;
      if (args.id && !old)
        throw new Error("Dieser Eintrag wurde inzwischen entfernt.");
      if (old) {
        if(chosen!==(old.pathIds?.[0]||""))setJournalPath(d,jid,chosen);
        old.text = text;
        old.subtype = v.kind;
        old.updatedAt = at;
        const r = d.reflections.find((r) => r.id === old.reflectionId);
        if (r) {
          r.text = text;
          r.updatedAt = at;
        }
      } else {
        const entry = {
          id: jid,
          type: args.ref
            ? "Bibel"
            : v.kind === "Predigt"
              ? "Predigt"
              : "Journal",
          subtype: v.kind,
          text,
          date: at,
          ref: args.ref || null,
          pathIds: [],
          reflectionId: rid,
          storyId: args.storyId || null,
        };
        d.journal.unshift(entry);
        d.reflections.unshift({
          id: rid,
          text,
          date: at,
          label: args.ref ? refLabel(args.ref) : v.kind,
          ref: args.ref || null,
          pathIds: [],
          storyId: args.storyId || null,
        });
      }
      if (chosen && !old) attach(d, chosen, jid);
      if (args.planId && v.planDone) {
        const key =
          args.planKind === "guide" ? "guide:" + args.planId : args.planId;
        d.guidedPlans[key] ??= {};
        d.guidedPlans[key][args.day] = true;
      }
    },(_,raw)=>completedDraft(draftSession,raw));
    await finishForm(draftSession);
    ui.continuitySaved = args.id ? null : jid;
    go("entry/" + encodeURIComponent(jid));
    notify("Dein Gedanke ist gespeichert.");
    if (!chosen && !args.id)
      connectSheet({
        entryId: jid,
        title: args.suggestTitle,
        category: args.category,
      });
  } else if (type === "path") {
    const title = v.title.trim();
    if (!title) throw new Error("Gib deinem Weg einen Namen.");
    const pid = args.id || id();
    change((d) => {
      let p = d.paths.find((p) => p.id === pid);
      if (args.id && !p)
        throw new Error("Dieser Weg ist nicht mehr vorhanden.");
      if (p) {
        p.title = title;
        p.why = v.why.trim();
        p.category = v.category;
        const step=p.steps.find(x=>!x.done);
        if(step && v.currentStep != null && v.currentStep.replace(/\r\n/g,"\n")!==step.text.replace(/\r\n/g,"\n")) { if(!v.currentStep.trim())throw new Error("Beschreibe den offenen Schritt.");step.text=v.currentStep.trim(); }
      } else {
        p = {
          id: pid,
          title,
          why: v.why.trim(),
          category: v.category,
          started: at,
          lastReview: null,
          steps: [],
          links: [],
          milestones: [],
          reviews: [],
          archived: false,
        };
        if (v.step?.trim())
          p.steps.push({
            id: id(),
            text: v.step.trim(),
            done: false,
            createdAt: at,
          });
        d.paths.unshift(p);
        d.reminderSnoozes["path:" + pid] = new Date(
          Date.now() + Number(v.days || 21) * 86400000,
        ).toISOString();
      }
      if (args.entryId) attach(d, pid, args.entryId);
      if (args.ref) addRef(d, pid, args.ref);
    });
    await finishForm(draftSession);
    go("path/" + encodeURIComponent(pid));
    notify(args.id ? "Weg aktualisiert." : "Dein Weg hat begonnen.");
  } else if (type === "step") {
    if (!v.text.trim()) throw new Error("Beschreibe deinen nächsten Schritt.");
    change((d) => {
      const p = d.paths.find((p) => p.id === args.pathId);
      if (!p) throw new Error("Dieser Weg fehlt.");
      if (args.stepId) {
        const step=p.steps.find(x=>x.id===args.stepId && !x.done);if(!step)throw new Error("Bereits ausprobierte Schritte werden nicht überschrieben.");step.text=v.text.trim();
      } else p.steps.push({id:id(),text:v.text.trim(),done:false,createdAt:at});
    });
    await finishForm(draftSession);
    go("path/" + encodeURIComponent(args.pathId));
    notify("Schritt festgehalten.");
  } else if (type === "review") {
    const status = v.status,
      confirmed = status === "changed" && v.development;
    let text = v.text.trim();
    if (["changed", "thought"].includes(status) && !text)
      throw new Error(
        status === "changed"
          ? "Beschreibe kurz, was sich verändert hat."
          : "Schreibe den Gedanken auf, den du festhalten möchtest.",
      );
    text ||= {
      working: "Ich arbeite noch daran.",
      unchanged: "Es hat sich nichts verändert.",
      notnow: "Im Moment nicht.",
    }[status];
    const key = args.gap?.key || "path:" + args.pathId,
      pid = args.pathId || args.gap?.pathId,
      reviewId = id();
    change((d) => {
      const review = {
        id: reviewId,
        date: at,
        text,
        status,
        confirmedDevelopment: !!confirmed,
        sourceKey: key,
        ref: args.gap?.ref || null,
      };
      const sourceSnapshot=capturePathReviewSource(d,args,at);
      if(sourceSnapshot)review.sourceSnapshot=sourceSnapshot;
      if(args.gap?.at&&!key.startsWith("path:"))review.sourceAt=args.gap.at;
      if (pid) {
        const p = d.paths.find((p) => p.id === pid);
        if (!p) throw new Error("Der Weg fehlt.");
        p.reviews.push(review);
        p.lastReview = at;
        if (confirmed)
          p.milestones.push({ id: id(), date: at, text, reviewId });
      } else d.reviews.unshift(review);
      delete d.reminderSnoozes[key];
      delete d.dismissedGaps[key];
      if (+v.days)
        d.reminderSnoozes[key] = new Date(
          Date.now() + Number(v.days) * 86400000,
        ).toISOString();
      else d.dismissedGaps[key] = at;
    });
    await finishForm(draftSession);
    go(pid ? "path/" + encodeURIComponent(pid) : "history");
    notify(
      confirmed
        ? "Deine Entwicklung ist festgehalten."
        : "Dein Rückblick ist gespeichert.",
    );
  }
}
function openGap(key) {
  const g = gaps(s()).find((g) => g.key === key);
  if (!g) return;
  ui.reviewInvite={gap:structuredClone(g),sourceSnapshot:capturePathReviewSource(s(),{gap:g,pathId:g.pathId},now())};
  modal(
    "Ein Gedanke von damals",
    `<span class="overline">${date(g.at)}</span><h3>${e(g.title)}</h3><blockquote class="previous-thought">${e(g.detail)}</blockquote><p>Was ist daraus geworden? Es gibt nichts zu bestehen.</p>${reminderWhy(g,date)}${button("Jetzt zurückblicken", "review-gap", { key }, "button primary full")}<div class="actions">${button("In zwei Wochen erinnern", "snooze", { key, days: 14 }, "button quiet")}${button("Im Moment nicht", "dismiss-gap", { key }, "text-button")}</div>${g.ref ? link("Den Bibeltext wieder lesen", readRoute(g.ref), "text-link") : ""}`,
  );
}
function download(object, name) {
  const a = document.createElement("a"),
    url = URL.createObjectURL(
      new Blob([JSON.stringify(object, null, 2)], { type: "application/json" }),
    );
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

function onboarding() {
  modal("Willkommen bei FaithPath",onboardingContent({button}));
  ui.onboardingOpen=true;
  $("#dialog").classList.add("onboarding-dialog");
}
function finishOnboarding(destination=null) {
  // Failure to persist an optional introduction must never prevent Bible access.
  try {localStorage.setItem(KEYS.onboard,"done");} catch {}
  ui.onboardingOpen=false;
  closeModal();
  if(destination)go(destination);else $("h1")?.focus({preventScroll:true});
}
const offlineStatus=()=>pwaController.status();
const pwa=()=>pwaController.start();

async function fillJourneyScripture(root) {
 try {
  const book=await getBook('EPH','l1912'),text=book.chapters[5].find(v=>v[0]===17)?.[1];
  if(!text||!root.isConnected)return;
  for(const quote of root.querySelectorAll('[data-journey-scripture]'))quote.textContent=text;
 }catch {if(root.isConnected)for(const quote of root.querySelectorAll('[data-journey-scripture]'))quote.textContent='Den Bibeltext findest du in Epheser 6,17.';}
}
function cancelNoteDeletion() {
  const pending=ui.noteDeletion;ui.noteDeletion=null;
  if(pending?.form){
    const expected=pending.draftSession?.expectedRaw??null;
    if(localStorage.getItem(KEYS.draft)!==expected){
      ui.editorRecovery={...pending.form,values:pending.values};
      modal("Ein neuerer Entwurf bleibt erhalten",`<p>Inzwischen wurde ein anderer Entwurf gespeichert. Sichere deine gerade bearbeiteten Worte als Datei, bevor du den anderen Entwurf öffnest.</p>${button("Meine Worte als Datei sichern","export-editor-recovery",{},"button primary full")}${button("Schließen","close",{},"button quiet")}`);
      return;
    }
    openForm(pending.form.type,pending.form.args,pending.values,expected);
  }else closeModal();
}
function confirmNoteDeletion(kind,id) {
  const note=(kind === "journal" ? s().journal : s().reflections).find(x=>x.id===id);
  if(!isBibleNote(note))throw new Error("Diese Bibelnotiz ist nicht mehr vorhanden.");
  ui.noteDeletion={kind,id,form:ui.form,values:ui.form ? snapshotForm() : null,draftSession:ui.draftSession};
  modal("Notiz an der Bibelstelle entfernen?",`<div id="form-error" role="alert" tabindex="-1"></div><p>Die Verbindung dieser Notiz mit der Bibelstelle wird entfernt. Markierung, Farbe und Wegverknüpfung bleiben erhalten.</p><p class="meta">${kind === "journal" ? "Dein Gedanke bleibt im Journal erhalten." : "Dein festgehaltener Gedanke bleibt in deiner Geschichte erhalten."}</p><div class="actions">${button("Abbrechen","cancel-note-delete",{},"button quiet")}${button("Notiz an der Bibelstelle entfernen","confirm-note-delete",{},"button danger")}</div>`);
  const title=$("#dialog-title");title.tabIndex=-1;title.focus({preventScroll:true});$("#dialog").scrollTop=0;
}
function confirmJournalDeletion(id) {
  const x=s().journal.find(j=>j.id===id);if(!x)throw new Error("Dieser Eintrag ist nicht mehr vorhanden.");
  ui.journalDeletion={id};
  const paths=(x.pathIds||[]).map(pid=>s().paths.find(p=>p.id===pid)).filter(Boolean);
  const reviews=reviewsFor(s(),x);
  modal("Journaleintrag wirklich löschen?",`<div id="form-error" role="alert" tabindex="-1"></div><p>Dieser Eintrag wird dauerhaft aus deinem Journal entfernt.</p>${paths.length?`<p class="meta">Dieser Eintrag ist mit deinem Weg „${e(paths[0].title)}“ verbunden.</p>`:""}${reviews.length?`<p class="meta">Zu diesem Eintrag existiert ein Rückblick. Sein Text bleibt erhalten; die Verbindung zum Eintrag wird entfernt.</p>`:""}<p class="meta">Deine Wege, Schritte, Bibelmarkierungen und unabhängigen Rückblicke bleiben erhalten.</p><div class="actions">${button("Abbrechen","close",{},"button quiet")}${button("Journaleintrag löschen","confirm-journal-delete",{},"button danger")}</div>`);
  const title=$("#dialog-title");title.tabIndex=-1;title.focus({preventScroll:true});$("#dialog").scrollTop=0;
}
async function action(a, d, el) {
  if(a==='seed-start'){finishOnboarding('first-seed');return;}
  if(a.startsWith('seed-')){await firstSeedController.handle(a,d);return;}
  if(a==='sword-info'){
    modal("Warum ein Schwert?",`${swordExplanation()}${button("Schließen","close",{},"button quiet")}`);fillJourneyScripture($("#dialog"));return;
  }
  if(a==='reset-book-search'){$("#book-search").value="";$("#book-list").innerHTML=bookList();$("#book-search").focus();return;}
  if(a==="set-theme"){
    if(!THEMES.some(t=>t.id===d.themeId))return;
    change(data=>{data.settings.theme=d.themeId;});applyTheme(document,d.themeId);more();$(`[data-theme-id="${d.themeId}"]`)?.focus({preventScroll:true});return;
  }
  el?.closest(".path-options,.entry-options")?.removeAttribute("open");
  if(a === "journal-path"){openForm("journal-path",{id:d.id});return;}
  if(a === "delete-journal"){confirmJournalDeletion(d.id);return;}
  if(a === "confirm-journal-delete") {
    const pending=ui.journalDeletion;if(!pending)throw new Error("Bitte öffne die Löschbestätigung erneut.");
    let draft=null;const snapshot=await journalTransaction(store,localStorage,data=>deleteJournalEntry(data,pending.id),(snapshot,raw)=>{if(journalDraftMatches(JSON.parse(raw||"null"),snapshot)){draft=raw;return null;}return raw;});
    ui.journalDeletion=null;closeModal();ui.continuitySaved=null;go("journal");
    undoNotice("Journaleintrag gelöscht",()=>journalTransaction(store,localStorage,data=>restoreJournalEntry(data,snapshot),(_,raw)=>{if(draft&&raw&&raw!==draft)throw new Error("Ein neuerer Entwurf bleibt erhalten. Rückgängig würde ihn überschreiben.");return draft||raw;}));return;
  }
  if(a === "dismiss-status"){$("#toast").classList.remove("visible");return;}
  if(a === "edit-note"){openForm("note",{id:d.id});return;}
  if(a === "delete-note"){confirmNoteDeletion(d.kind,d.id);return;}
  if(a === "cancel-note-delete"){cancelNoteDeletion();return;}
  if(a === "confirm-note-delete") {
    const pending=ui.noteDeletion;if(!pending)throw new Error("Bitte öffne die Löschbestätigung erneut.");
    let snapshot;change(data=>snapshot=deleteBibleNote(data,pending.kind,pending.id,now()));
    // Removing the Bible-note role does not discard unsaved personal words.
    // A resumed former-note draft edits its retained text without restoring that role.
    ui.noteDeletion=null;closeModal();await render();
    undoNotice("Notiz an der Bibelstelle entfernt",()=>change(data=>restoreBibleNote(data,snapshot)));return;
  }
  if (a === "close") {
    if(ui.onboardingOpen){finishOnboarding();return;}
    if(ui.noteDeletion){cancelNoteDeletion();return;}
    closeModal();
    return;
  }
  if (a === "plan-toggle") {
    change((data) => {
      const key = d.kind === "guide" ? "guide:" + d.id : d.id;
      data.guidedPlans[key] ??= {};
      data.guidedPlans[key][d.day] = !data.guidedPlans[key][d.day];
    });
    plan(d.kind, d.id);
    return;
  }
  if (a === "new-entry") {
    openForm("entry");
    return;
  }
  if (a === "new-path") {
    openForm("path");
    return;
  }
  if (a === "edit-path") {
    openForm("path", { id: d.id });
    return;
  }
  if (a === "edit-entry") {
    openForm("entry", { id: d.id });
    return;
  }
  if (a === "reflect-path") {
    openForm("entry", { pathId: d.id, kind: "Reflexion" });
    return;
  }
  if (a === "step") {
    openForm("step", { pathId: d.id });
    return;
  }
  if (a === "use-suggestion") {
    $("[name=text]", $("#dialog")).value = d.text;
    persistDraft();
    return;
  }
  if (a === "resume") {
    const raw=localStorage.getItem(KEYS.draft),x = JSON.parse(raw || "null");
    if(x?.type==='first-seed'){if(ui.onboardingOpen)finishOnboarding('first-seed');else{closeModal();go('first-seed');}return;}
    if (x) openForm(x.type, x.args, x.values,raw);
    return;
  }
  if(a === "export-draft"){
    const raw=localStorage.getItem(KEYS.draft);
    if(raw!==null)download({app:"FaithPath-Entwurf",draft:JSON.parse(raw)},"FaithPath-Entwurf.json");
    return;
  }
  if(a === "export-editor-recovery"){
    if(ui.editorRecovery)download({app:"FaithPath-Entwurf",draft:ui.editorRecovery},"FaithPath-Entwurf.json");
    return;
  }
  if(a === "discard-and-open"){
    const pending=ui.pendingForm;if(!pending)return;
    await discardDraft(localStorage,pending.raw);ui.pendingForm=null;
    openForm(pending.type,pending.args);
    return;
  }
  if (a === "focus-passage") {
    const v = $(`[data-v="${ui.reader.ref.from}"]`);
    v?.scrollIntoView({
      block: "start",
      behavior: matchMedia("(prefers-reduced-motion:reduce)").matches
        ? "instant"
        : "smooth",
    });
    v?.focus({ preventScroll: true });
    return;
  }
  if (a === "verse") {
    const v = +d.v;
    ui.selection.has(v) ? ui.selection.delete(v) : ui.selection.add(v);
    selectionBar();
    return;
  }
  if (a === "clear-selection") {
    const previousVerse=[...ui.selection].at(-1);
    ui.selection.clear();
    selectionBar();
    $(`.verse[data-v="${previousVerse}"]`)?.focus({preventScroll:true});
    return;
  }
  if (a === "undo-core") {
    const undo = ui.undo;
    if (!undo || Date.now() > undo.expires) { notify("Die Zeit zum Rückgängigmachen ist vorbei."); return; }
    try{await undo.restore();}catch(error){notify(error.message,true);$("#toast").insertAdjacentHTML("beforeend",button("Rückgängig","undo-core",{},"text-button"));return;}
    ui.undo = null; notify("Wiederhergestellt"); render(); return;
  }
  if (a === "mark") { const ref = selection(); if (ref) colorPalette({ref}); return; }
  if (a === "highlight-color") { colorPalette({id:d.id}); return; }
  if (a === "paint-highlight") {
    const ref = validRef(JSON.parse(d.ref),ui.refs);
    change(data => {
      if (d.id) { const h=data.highlights.find(h=>h.id===d.id); if (!h) throw new Error("Diese Markierung fehlt."); h.color=d.color; }
      else paintRange(data,ref,d.color,ui.reader.vs,id,now());
    });
    closeModal();
    if ($(".reader-page")) { refreshHighlights(); selectionBar(); } else render();
    notify("Markierung geändert"); return;
  }
  if (a === "highlight-note") {
    const h=s().highlights.find(h=>h.id===d.id); if (!h) return;
    const note=markNotes(h)[0];openForm(note?.kind === "reflection" ? "note" : "entry",note ? {id:note.id} : {ref:h,kind:"Reflexion"});return;
  }
  if (a === "reset-discover") {
    ui.storySearch="";ui.storyBook="";ui.storyKind="alle";ui.storyLimit=DISCOVERY_PAGE_SIZE;
    $("#story-search").value="";$("#story-book").value="";$("#story-kind").value="alle";refreshDiscovery();$("#story-search").focus();return;
  }
  if(a === "more-discover") { const previousCount=discoverySelection().visible.length;ui.storyLimit+=DISCOVERY_PAGE_SIZE;refreshDiscovery({focusNew:true,previousCount});return; }
  if(a === "discover-kind") {ui.storyKind=d.kind;ui.storyLimit=DISCOVERY_PAGE_SIZE;$("#story-kind").value=d.kind;refreshDiscovery();$("#discovery-results-title").focus();$("#discovery-results-title").scrollIntoView({block:"start"});return;}
  if (a === "reset-mark-filters") { ui.markColor="";ui.markBook="";ui.markContext="";marks();return; }
  if (a === "edit-step") { openForm("step",{pathId:d.path,stepId:d.id});return; }
  if (a === "current-step") {
    change(data=>{ const p=data.paths.find(p=>p.id===d.path), i=p.steps.findIndex(x=>x.id===d.id && !x.done);if(i<0)throw new Error("Dieser offene Schritt fehlt.");p.steps.unshift(...p.steps.splice(i,1)); });path(d.path);notify("Als Nächstes ausgewählt");return;
  }
  if (a === "reflect-reader") {
    const ctx = ui.reader.context || {};
    openForm("entry", {
      ref: currentRef(),
      kind: "Reflexion",
      question: ctx.question,
      ...ctx,
      suggestTitle: ctx.title,
    });
    return;
  }
  if (a === "reflect-story") {
    const x = ui.stories.find((x) => String(x.id) === d.id) || runtimeModel.stories.get(d.id);
    if (!x) return;
    openForm("entry", {
      ref: validRef(
        {...(x.references?.[0] || {book:x.book,chapter:x.chapter+1,from:x.from,to:x.to}),label:x.ref,translation:x.kind==="chapter-quiz" ? "l1912" : s().translation},
        ui.refs,
      ),
      kind: "Reflexion",
      question: x.reflection,
      storyId: x.story_id || x.id,
      suggestTitle: x.title,
    });
    return;
  }
  if (a === "connect-reader") {
    connectSheet({ ref: currentRef() });
    return;
  }
  if (a === "connect-entry") {
    connectSheet({ entryId: d.id });
    return;
  }
  if (a === "connect-ref") {
    connectSheet({ ref: validRef(JSON.parse(d.ref), ui.refs) });
    return;
  }
  if (a === "path-from") {
    openForm("path", JSON.parse(d.args));
    return;
  }
  if (a === "attach") {
    const args = JSON.parse(d.args);
    change((data) => {
      if (args.entryId) attach(data, d.path, args.entryId);
      if (args.ref) addRef(data, d.path, args.ref);
    });
    closeModal();
    go("path/" + encodeURIComponent(d.path));
    notify("Teil deines Weges.");
    return;
  }
  if (a === "copy") {
    const r = currentRef(),
      text =
        refLabel(r) +
        "\n" +
        ui.reader.vs
          .filter((v) => !r.from || (v[0] >= r.from && v[0] <= r.to))
          .map((v) => v[0] + " " + v[1])
          .join("\n") +
        "\n" +
        TRANSLATIONS[r.translation].name;
    try {
      await navigator.clipboard.writeText(text);
      notify("Bibeltext kopiert.");
    } catch {
      modal(
        "Bibeltext kopieren",
        textarea("Text zum Kopieren", "copyText", text) +
          "<p>Markiere den Text und wähle „Kopieren“.</p>",
      );
    }
    return;
  }
  if (a === "remove-selected-highlight") {
    modal("Markierung entfernen?", `<p>${e(refLabel(JSON.parse(d.ref)))}</p><p>Nur die ausgewählten Verse werden entfernt. Notizen und verbundene Wege bleiben erhalten.</p>${button("Markierung entfernen","confirm-remove-mark",{ref:d.ref},"button quiet")}`);return;
  }
  if (a === "remove-mark") {
    modal(
      "Markierung entfernen?",
      `<p>Notizen und verbundene Wege bleiben erhalten.</p>${button("Markierung entfernen", "confirm-remove-mark", { id: d.id }, "button quiet")}`,
    );
    return;
  }
  if (a === "confirm-remove-mark") {
    const before=structuredClone(s().highlights);
    change(data=>{if(d.ref)clearRange(data,validRef(JSON.parse(d.ref),ui.refs),ui.reader.vs,id);else data.highlights=data.highlights.filter(h=>h.id!==d.id);});
    const after=JSON.stringify(s().highlights);
    closeModal();if($(".reader-page")){refreshHighlights();selectionBar();}else go("marks");
    undoNotice("Markierung entfernt",()=>change(data=>{if(JSON.stringify(data.highlights)!==after)throw new Error("Die Markierungen wurden inzwischen geändert. Rückgängig ist nicht mehr sicher.");data.highlights=before;}));return;
  }
  if (a === "explore-chapter") {
    if(ui.reader?.needsConfirmation)acknowledgeReaderChapter();
    return;
  }
  if (a === "skip-chapter-quiz") {
    $(".reader-chapter-questions")?.remove();
    $(".chapter-nav a")?.focus();
    return;
  }
  if (a === "quiz") {
    const x = ui.stories.find((x) => String(x.id) === d.id);
    if (!x) return;
    const canonical=canonicalStoryForLegacy(x);
    if(canonical){go("question/"+canonical.flow_items[0].primary_question_id);return;}
    ui.quiz = { story: x, index: 0, answer: null };
    go(chapterQuizRoute(x, "story/" + x.id));
    return;
  }
  if (a === "answer") {
    if (ui.quiz.answer != null) return;
    ui.quiz.answer = +d.answer;
    quiz();
    $(".explanation")?.focus();
    return;
  }
  if (a === "next-question") {
    if (!ui.quiz || ui.quiz.answer == null) return;
    if (ui.quiz.index < ui.quiz.story.questions.length - 1) {
      ui.quiz.index++;
      ui.quiz.answer = null;
      quiz();
      $("h1")?.focus();
    } else {
      const x = ui.quiz.story;
      change((data) => (data.quiz[x.id] = { ...data.quiz[x.id], done: now() }));
      const route = chapterQuizRoute(x, ui.quiz.returnRoute);
      go(route + (route.includes("?") ? "&" : "?") + "complete=1");
    }
    return;
  }
  if (a === "review-path") {
    openForm("review", { pathId: d.id });
    return;
  }
  if (a === "gap") {
    openGap(d.key);
    return;
  }
  if (a === "review-gap") {
    const invitation=ui.reviewInvite?.gap.key===d.key?ui.reviewInvite:null;
    const g=invitation?.gap||gaps(s()).find(g=>g.key===d.key);
    if(g)openForm("review",{gap:g,pathId:g.pathId,...(invitation?.sourceSnapshot?{sourceSnapshot:invitation.sourceSnapshot}:{})});
    return;
  }
  if(a === "resume-reminder") {if(!selectReminderControls(s()).paused.some(g=>g.key===d.key))throw new Error("Diese Einladung wurde inzwischen verändert.");change(data=>{delete data.reminderSnoozes[d.key];delete data.dismissedGaps[d.key];});reviews();notify("Einladung wieder zugelassen. Sie erscheint nur beim Nutzen der App.");return;}
  if (a === "snooze" || a === "dismiss-gap") {
    change((data) => {
      if (a === "snooze") {
        data.reminderSnoozes[d.key] = new Date(
          Date.now() + +d.days * 86400000,
        ).toISOString();
        delete data.dismissedGaps[d.key];
      } else data.dismissedGaps[d.key] = now();
    });
    closeModal();
    render();
    notify(
      a === "snooze"
        ? "Frühestens in zwei Wochen wieder beim Öffnen der App."
        : "Für jetzt beiseitegelegt.",
    );
    return;
  }
  if (a === "toggle-archive") {
    ui.archive = !ui.archive;
    paths();
    return;
  }
  if (a === "archive-path") {
    change((data) => {
      const p = data.paths.find((p) => p.id === d.id);
      p.archived = !p.archived;
    });
    path(d.id);
    notify(s().paths.find(p=>p.id===d.id).archived ? "Weg archiviert" : "Weg wieder aufgenommen");
    return;
  }
  if (a === "delete-path") {
    modal(
      "Weg wirklich löschen?",
      `<p><strong>${e(s().paths.find(p=>p.id===d.id)?.title)}</strong></p><p>Der Weg, seine Schritte und Wegzuordnungen werden entfernt. Journalgedanken und Bibelmarkierungen bleiben. Rückblicke und dokumentierte Entwicklung bleiben in deiner Geschichte erhalten.</p>${button("Abbrechen", "close", {}, "button quiet")}<div class="actions">${button("Lieber archivieren", "archive-and-close", { id: d.id }, "button primary")}${button("Weg endgültig löschen", "confirm-delete", { id: d.id }, "button quiet danger-text")}</div>`,
    );
    return;
  }
  if (a === "archive-and-close") {
    change((data) => {
      data.paths.find((p) => p.id === d.id).archived = true;
    });
    closeModal();
    go("paths");
    return;
  }
  if (a === "confirm-delete") {
    const before=structuredClone(s());change(data=>detachPath(data,d.id));const after=JSON.stringify(s());
    closeModal();go("paths");
    undoNotice("Weg gelöscht",()=>change(data=>{if(JSON.stringify(data)!==after)throw new Error("Seit dem Löschen wurde etwas gespeichert. Rückgängig würde diese Daten überschreiben und ist deshalb nicht möglich.");for(const key of Object.keys(data))delete data[key];Object.assign(data,before);}));return;
  }
  if(a === "reset-journal") {ui.search="";ui.filter="Alle";ui.journalLimit=40;journal();$("#journal-search")?.focus();return;}
  if (a === "journal-filter") {
    ui.filter = d.filter;
    ui.journalLimit = 40;
    refreshJournal();
    return;
  }
  if (a === "more-journal") {
    const count=$$("[data-journal-id]").length;
    ui.journalLimit += 40;
    refreshJournal();
    $$("[data-journal-id] h3 a")[count]?.focus();
    return;
  }
  if(a === "more-reviews"){const before=$$("[data-review-id]").length;ui.reviewsLimit+=40;reviews();$$("[data-review-id] .continuity-after a")[before]?.focus();return;}
  if (a === "more-history") {
    ui.historyExpanded = true;
    const previousLimit=ui.historyLimit;
    ui.historyLimit += 40;
    d.path ? path(d.path) : history();
    if(d.path){const first=$$(".path-story .timeline li")[previousLimit],target=first?.querySelector("a")||first;if(target){target.tabIndex=-1;target.focus();}}
    return;
  }
  if(backupController.handles(a)) {await backupController.handle(a,d,el);return;}
  if (a === "onboard") {
    onboarding();
    return;
  }
  if (a === "onboard-next") {finishOnboarding("guidance");return;}
  if (a === "onboard-skip") {finishOnboarding("bible");return;}
  if (a === "offline-check") {
    notify(
      (await offlineStatus())
        ? "Offline bereit."
        : "Noch nicht vollständig offline vorbereitet.",
    );
    return;
  }
  if (a === "update") {await pwaController.activateUpdate();return;}
}

const pwaController=createPwaController({
 build:BUILD,getServiceWorker:()=>navigator.serviceWorker,
 onStatus:ready=>{ui.offline=ready;const field=$("#offline-state");if(field)field.textContent=ready?"Beide Bibeln und die App sind für dieses Gerät offline bereit.":"Noch nicht offline bereit. Bleibe online und lade die App bei Bedarf neu.";},
 onWaiting:worker=>{ui.waiting=worker;if(!worker){$(".update-notice")?.remove();return;}if(!$(".update-notice"))$(".page")?.insertAdjacentHTML("afterbegin",`<aside class="update-notice" role="status">Eine neue Version ist bereit. ${button("Jetzt aktualisieren","update",{},"text-button")}</aside>`);},
 onNotice:notify,reload:()=>location.reload(),isDialogOpen:()=>$("#dialog").open||firstSeedController.hasUnsavedWork(),
 addFocusListener:listener=>window.addEventListener("focus",listener)
});
const backupController=createBackupController({
 store,storage:deviceStorage,getRoute:()=>location.hash,getReferences:()=>ui.refs,locks:navigator.locks,find:$,
 view:{modal,closeModal,go,notify,download,button,date}
});
const firstSeedController=createFirstSeedController({store,storage:deviceStorage,getReferences:()=>ui.refs,getBook,id,now,view:{shell,button,link,go,notify,download,modal,closeModal,find:$}});
const render=createAppRouter({
 ui,getState:s,canonicalStoryForLegacy,go,storage:deviceStorage,document,window,location,
 helpers:{shell,heading,back,button},
 views:{firstSeed:()=>firstSeedController.render(),mergedStory,sourceQuestion,home,guidance,topic,bible,chapters,chapterCollection,reader,marks,markDetail,discover,story,quizIndex,quiz,chapterQuizComplete,paths,path,tree,plans,plan,journal,entry,history,reviews,more,contentStatus,licenses,openForm,notFound,fillJourneyScripture}
});
document.addEventListener("focusin",event=>{
  const tab=event.target.closest?.(".segmented a");if(!tab)return;
  const container=tab.parentElement,box=container.getBoundingClientRect(),r=tab.getBoundingClientRect();
  if(r.right>box.right)container.scrollLeft+=r.right-box.right+2;
  else if(r.left<box.left)container.scrollLeft+=r.left-box.left-2;
});
document.addEventListener("keydown", event => {
  if(event.target.matches?.(".color-choice") && ["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(event.key)) {
    const options=$$(".color-choice"),i=options.indexOf(event.target),delta=["ArrowLeft","ArrowUp"].includes(event.key)?-1:1;
    event.preventDefault();const next=event.key==="Home"?0:event.key==="End"?options.length-1:(i+delta+options.length)%options.length;options.forEach((option,k)=>option.tabIndex=k===next?0:-1);options[next]?.focus();
  }
  if (event.key === "Escape") document.querySelector(".path-options[open],.entry-options[open]")?.removeAttribute("open");
});
document.addEventListener("click", (ev) => {
  if (ev.target.closest(".skip-link")) {
    ev.preventDefault();
    const main = $("#main");
    if (main) {
      main.tabIndex = -1;
      main.focus();
    }
    return;
  }
  const target = ev.target.closest("[data-action]");
  if (target) {
    if (target.dataset.action === "retry") {
      render();
      return;
    }
    Promise.resolve(
      action(target.dataset.action, target.dataset, target),
    ).catch(showError);
  }
  const anchor = ev.target.closest('a[href^="#"]');
  if(anchor&&ui.route.split("?")[0]==="journal"&&anchor.closest("[data-journal-id]"))ui.journalReturn={id:anchor.closest("[data-journal-id]").dataset.journalId,scroll:scrollY};
  if (anchor && $("#dialog").open) closeModal();
});
document.addEventListener("submit", (ev) => {
  if (ev.target.id === "editor-form") {
    ev.preventDefault();
    if(ui.saving)return;
    ui.saving=true;
    const controls=$$("button,input,textarea,select",$("#dialog")).map(el=>[el,el.disabled]);
    for(const [el] of controls)el.disabled=true;
    submitForm().catch(showError).finally(()=>{
      ui.saving=false;
      for(const [el,disabled] of controls)if(el.isConnected)el.disabled=disabled;
    });
  }
});
document.addEventListener("input", (ev) => {
  const el = ev.target;
  if(el.closest('.seed-editor')){firstSeedController.input(el);return;}
  if (el.closest("#editor-form")) persistDraft();
  if (el.dataset.input === "books")
    $("#book-list").innerHTML = bookList(el.value);
  if (el.dataset.input === "journal") {
    ui.search = el.value;
    ui.journalLimit = 40;
    refreshJournal();
  }
  if (el.dataset.input === "stories") {
    ui.storySearch = el.value;ui.storyLimit=DISCOVERY_PAGE_SIZE;
    refreshDiscovery();
  }
});
document.addEventListener("change", (ev) => {
  const el = ev.target;
  if(el.closest('.seed-editor')){firstSeedController.input(el);return;}
  try {
    if (el.name === "status") updateDevelopment();
    if (el.closest("#editor-form")) persistDraft();
    if (el.id === "import-file") {
      backupController.inspectFile(el.files[0]).catch((err) =>
        notify("Import abgebrochen: " + err.message, true),
      );
      el.value = "";
      return;
    }
    const c = el.dataset.change;
    if (c?.startsWith("mark-")) { ui[{"mark-color":"markColor","mark-book":"markBook","mark-context":"markContext"}[c]]=el.value;marks();return; }
    if (c === "translation") {
      const ref = validRef(
        { ...ui.reader.ref, translation: el.value },
        ui.refs,
      );
      change((data) => (data.translation = el.value));
      go(readRoute(ref, ui.reader.origin));
    } else if (c === "reader-book")
      go(
        readRoute({
          book: el.value,
          chapter: 1,
          translation: ui.reader.ref.translation,
        }),
      );
    else if (c === "reader-chapter")
      go(
        readRoute({
          book: ui.reader.ref.book,
          chapter: +el.value,
          translation: ui.reader.ref.translation,
        }),
      );
    else if (c === "step-done") {
      change((data) => {
        const p = data.paths.find((p) => p.id === el.dataset.path),
          step = p.steps.find((x) => x.id === el.dataset.id);
        step.done = el.checked;
        step.completedAt = el.checked ? now() : null;
      });
      path(el.dataset.path);
      const next=$(".next-step input")||$("#path-next-step-title");
      if(next){if(next.tagName!=="INPUT")next.tabIndex=-1;next.focus();}
    } else if (c === "story-book") {
      ui.storyBook = el.value;ui.storyLimit=DISCOVERY_PAGE_SIZE;
      refreshDiscovery();
    } else if (c === "story-kind") {
      ui.storyKind = el.value;ui.storyLimit=DISCOVERY_PAGE_SIZE;
      refreshDiscovery();
    }
  } catch (err) {
    showError(err);
    if (el.type === "checkbox") el.checked = !el.checked;
  }
});
$("#dialog").addEventListener("cancel",ev=>{if(ui.onboardingOpen){ev.preventDefault();finishOnboarding();return;}if(ui.saving){ev.preventDefault();return;}if(ui.noteDeletion){ev.preventDefault();cancelNoteDeletion();}else if(ui.journalDeletion){ev.preventDefault();closeModal();}});
$("#dialog").addEventListener("close", () => {
  if (!$("#dialog").open) {
    ui.form = null;backupController.invalidate();
    document.body.classList.remove("modal-open");
  }
});
window.addEventListener("hashchange", async () => {
  if(firstSeedController.isActive()&&location.hash.split('?')[0]!=='#first-seed'){
    try{await firstSeedController.leave();}catch(error){notify('Dein Entwurf ist noch nicht gesichert. '+error.message,true);location.replace('#first-seed');return;}
  }
  backupController.invalidate(); // Invalidate even a later return to the same hash.
  if(ui.onboardingOpen&&ui.dialogRoute!==location.hash.slice(1))finishOnboarding();
  if ($("#dialog").open && ui.dialogRoute !== location.hash.slice(1))
    closeModal();
  render();
});
window.addEventListener("online", () => offlineStatus());
window.addEventListener('beforeunload',event=>{if(firstSeedController.hasUnsavedWork()){event.preventDefault();event.returnValue='';}});
window.addEventListener("offline", () =>
  notify("Du bist offline. Bereits vorbereitete Inhalte bleiben verfügbar."),
);
window.addEventListener("storage", (ev) => {
  if (ev.key === KEYS.main)
    notify(
      "Dein Datenstand wurde in einem anderen Tab geändert. Bitte lade diese Seite neu, bevor du weiterschreibst.",
      true,
    );
});
async function init() {
  try {
    runtimeModel = await loadRuntimeModel(CONTENT_BASE);
    ui.books = runtimeModel.books;
    ui.stories = runtimeModel.units;
    ui.chapterCatalog = createChapterCatalog(ui.stories, ui.books);
    ui.discoveryIndex=createDiscoveryIndex(discoveryItems());
    ui.discoveryBooks=new Set(ui.discoveryIndex.map(item=>item.book));
    ui.refs = runtimeModel.refs;
    await render();
    if(journalRecoveryError)notify(journalRecoveryError.message,true);
    pwa();
    if (
      !store.error && ui.route!=='first-seed' &&
      !localStorage.getItem(KEYS.onboard) &&
      !localStorage.getItem(KEYS.legacyOnboard)
    )
      onboarding();
  } catch (err) {
    shell(
      `${heading("FaithPath", "Die App konnte nicht starten.", err.message)}${button("Erneut versuchen", "reload", {}, "button primary")}`,
    );
  }
}
document.addEventListener("click", (ev) => {
  if (ev.target.closest("[data-action=reload]")) location.reload();
});
init();

function mergedStory(id) {
  const x=runtimeModel.stories.get(id);if(!x)return notFound();
  const ref=validRef({...x.references[0],translation:s().translation},ui.refs);
  shell(`${back("Entdecken","discover")}${heading(x.ref,x.title)}<p class="story-flow-intro">Lies den Bibeltext in Ruhe. Die Fragen helfen dir beim Verstehen – dein eigener Gedanke darf daraus wachsen.</p><div class="story-flow-steps" aria-label="Dein Weg durch die Geschichte"><span>Lesen</span><span>Verstehen</span><span>Reflektieren</span></div><div class="actions">${link("Abschnitt lesen",readRoute(ref,"merged-story/"+id),"button primary")}${link("Fragen zur Geschichte","question/"+x.flow_items[0].primary_question_id,"button quiet")}</div><section data-story-id="${e(id)}" class="section story-question-list"><h2>Fragen zur Geschichte</h2><p class="meta">Du kannst jede Frage einzeln öffnen und Fragen überspringen. Antworten werden hier nicht dauerhaft als Abschluss gespeichert.</p>${x.flow_items.map((item,index)=>{const q=runtimeModel.fp.get(item.primary_question_id)?.question || runtimeModel.n.get(item.primary_question_id);return row(q.q,`Frage ${index+1} von ${x.flow_items.length}`,"question/"+item.primary_question_id);}).join("")}</section><section class="reflection-invite"><span class="overline">Deine Reflexion</span><h2>${e(x.reflection)}</h2>${button("Gedanken festhalten","reflect-story",{id:x.story_id},"button primary")}<p class="meta">Deine Reflexion wird nicht bewertet.</p></section>`,"bible","merged-story-page depth-page");
}
function sourceQuestion(id) {
  const state=storyQuestionState(runtimeModel,id,ui);if(!state)return notFound();
  shell(renderStoryQuestion(state,{back,heading,link}),"bible","merged-question-page depth-page");
}
document.addEventListener("click",ev=>{
  const target=ev.target.closest('[data-action="source-answer"]');if(!target || target.disabled)return;
  ui.sourceAnswerId=target.dataset.id;ui.sourceAnswer=Number(target.dataset.answer);sourceQuestion(target.dataset.id);
  const feedback=$(".explanation");if(feedback){feedback.tabIndex=-1;feedback.focus();}
});

document.addEventListener("keydown",event=>{
 const tile=event.target.closest?.(".theme-tile");if(!tile||!["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(event.key))return;event.preventDefault();const ids=THEMES.map(t=>t.id),i=ids.indexOf(tile.dataset.themeId),next=event.key==="Home"?0:event.key==="End"?ids.length-1:(i+(["ArrowRight","ArrowDown"].includes(event.key)?1:-1)+ids.length)%ids.length;
 Promise.resolve(action("set-theme",{themeId:ids[next]},tile)).catch(showError);
});
