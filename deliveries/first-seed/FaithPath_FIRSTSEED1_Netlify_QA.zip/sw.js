const BUILD = "FP4-20261019-G-STABLE1-FIRSTSEED1";
const PREFIX = "faithpath:" + self.registration.scope;
const CACHE = PREFIX + BUILD;
const ASSETS = ["./404.html","./BUILD.txt","./candidate-integrity.json","./data/bibles/LUTHER1912-NOTICE.txt","./data/bibles/OTB-LICENSE.txt","./data/bibles/l1912/1CH.json","./data/bibles/l1912/1CO.json","./data/bibles/l1912/1JN.json","./data/bibles/l1912/1KI.json","./data/bibles/l1912/1PE.json","./data/bibles/l1912/1SA.json","./data/bibles/l1912/1TH.json","./data/bibles/l1912/1TI.json","./data/bibles/l1912/2CH.json","./data/bibles/l1912/2CO.json","./data/bibles/l1912/2JN.json","./data/bibles/l1912/2KI.json","./data/bibles/l1912/2PE.json","./data/bibles/l1912/2SA.json","./data/bibles/l1912/2TH.json","./data/bibles/l1912/2TI.json","./data/bibles/l1912/3JN.json","./data/bibles/l1912/ACT.json","./data/bibles/l1912/AMO.json","./data/bibles/l1912/COL.json","./data/bibles/l1912/DAN.json","./data/bibles/l1912/DEU.json","./data/bibles/l1912/ECC.json","./data/bibles/l1912/EPH.json","./data/bibles/l1912/EST.json","./data/bibles/l1912/EXO.json","./data/bibles/l1912/EZK.json","./data/bibles/l1912/EZR.json","./data/bibles/l1912/GAL.json","./data/bibles/l1912/GEN.json","./data/bibles/l1912/HAB.json","./data/bibles/l1912/HAG.json","./data/bibles/l1912/HEB.json","./data/bibles/l1912/HOS.json","./data/bibles/l1912/ISA.json","./data/bibles/l1912/JAS.json","./data/bibles/l1912/JDG.json","./data/bibles/l1912/JER.json","./data/bibles/l1912/JHN.json","./data/bibles/l1912/JOB.json","./data/bibles/l1912/JOL.json","./data/bibles/l1912/JON.json","./data/bibles/l1912/JOS.json","./data/bibles/l1912/JUD.json","./data/bibles/l1912/LAM.json","./data/bibles/l1912/LEV.json","./data/bibles/l1912/LUK.json","./data/bibles/l1912/MAL.json","./data/bibles/l1912/MAT.json","./data/bibles/l1912/MIC.json","./data/bibles/l1912/MRK.json","./data/bibles/l1912/NAM.json","./data/bibles/l1912/NEH.json","./data/bibles/l1912/NUM.json","./data/bibles/l1912/OBA.json","./data/bibles/l1912/PHM.json","./data/bibles/l1912/PHP.json","./data/bibles/l1912/PRO.json","./data/bibles/l1912/PSA.json","./data/bibles/l1912/REV.json","./data/bibles/l1912/ROM.json","./data/bibles/l1912/RUT.json","./data/bibles/l1912/SNG.json","./data/bibles/l1912/TIT.json","./data/bibles/l1912/ZEC.json","./data/bibles/l1912/ZEP.json","./data/bibles/otb/1CH.json","./data/bibles/otb/1CO.json","./data/bibles/otb/1JN.json","./data/bibles/otb/1KI.json","./data/bibles/otb/1PE.json","./data/bibles/otb/1SA.json","./data/bibles/otb/1TH.json","./data/bibles/otb/1TI.json","./data/bibles/otb/2CH.json","./data/bibles/otb/2CO.json","./data/bibles/otb/2JN.json","./data/bibles/otb/2KI.json","./data/bibles/otb/2PE.json","./data/bibles/otb/2SA.json","./data/bibles/otb/2TH.json","./data/bibles/otb/2TI.json","./data/bibles/otb/3JN.json","./data/bibles/otb/ACT.json","./data/bibles/otb/AMO.json","./data/bibles/otb/COL.json","./data/bibles/otb/DAN.json","./data/bibles/otb/DEU.json","./data/bibles/otb/ECC.json","./data/bibles/otb/EPH.json","./data/bibles/otb/EST.json","./data/bibles/otb/EXO.json","./data/bibles/otb/EZK.json","./data/bibles/otb/EZR.json","./data/bibles/otb/GAL.json","./data/bibles/otb/GEN.json","./data/bibles/otb/HAB.json","./data/bibles/otb/HAG.json","./data/bibles/otb/HEB.json","./data/bibles/otb/HOS.json","./data/bibles/otb/ISA.json","./data/bibles/otb/JAS.json","./data/bibles/otb/JDG.json","./data/bibles/otb/JER.json","./data/bibles/otb/JHN.json","./data/bibles/otb/JOB.json","./data/bibles/otb/JOL.json","./data/bibles/otb/JON.json","./data/bibles/otb/JOS.json","./data/bibles/otb/JUD.json","./data/bibles/otb/LAM.json","./data/bibles/otb/LEV.json","./data/bibles/otb/LUK.json","./data/bibles/otb/MAL.json","./data/bibles/otb/MAT.json","./data/bibles/otb/MIC.json","./data/bibles/otb/MRK.json","./data/bibles/otb/NAM.json","./data/bibles/otb/NEH.json","./data/bibles/otb/NUM.json","./data/bibles/otb/OBA.json","./data/bibles/otb/PHM.json","./data/bibles/otb/PHP.json","./data/bibles/otb/PRO.json","./data/bibles/otb/PSA.json","./data/bibles/otb/REV.json","./data/bibles/otb/ROM.json","./data/bibles/otb/RUT.json","./data/bibles/otb/SNG.json","./data/bibles/otb/TIT.json","./data/bibles/otb/ZEC.json","./data/bibles/otb/ZEP.json","./icons/icon-192.png","./icons/icon-512.png","./icons/olive-v2-180.png","./icons/olive-v2-192.png","./icons/olive-v2-32.png","./icons/olive-v2-512.png","./index.html","./manifest.webmanifest","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/content-report.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/faithpath-content-index.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/faithpath-nachlese-story-flow.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/index.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/nachlese-questions.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/nachlese-stories.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/nt-quiz-status.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/reference-index.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/data/stories.json","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/app-router.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/app.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/backup-controller.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/backup-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/backup-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/bible-journey.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/bible-loader.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/bible-notes.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/chapter-questions.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/content.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/continuity.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/core-experience.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/discover-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/discover-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/domain.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/drafts.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/experience-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/first-seed/controller.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/first-seed/model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/first-seed/view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/import-validation.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journal-management.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journal-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journal-reviews-backup.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journal-search.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journal-storage.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journal-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journey-sword.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/journey-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/living-motion.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/menu.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/navigation-discovery.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/navigation-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/navigation-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/olive-tree.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/onboarding-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/path-review-context.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/paths-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/paths-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/personal-journey.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/pwa-controller.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/reader-stories.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/reader-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/reminders-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/reviews-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/reviews-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/runtime-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/store.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/story-flow-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/themes.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/today-model.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/today-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/today.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/tree-branches.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/tree-stage-guide.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/tree-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/brand-sprig.svg","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/fonts/DMSans.ttf","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/fonts/Newsreader-Italic.ttf","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/fonts/Newsreader.ttf","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/licenses/dmsans-OFL.txt","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/licenses/newsreader-OFL.txt","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/assets/sword-seal.svg","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/dialog-view.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/discover.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/foundation.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/interaction.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/personal.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/reader-flow.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/reader.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/seed.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/system.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/today.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/verbunden/tokens.css","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/version.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/src/view-html.js","./releases/FP4-20261019-G-STABLE1-FIRSTSEED1/styles.css","./trees/tree-stage-1.webp","./trees/tree-stage-2.webp","./trees/tree-stage-3.webp","./trees/tree-stage-4.webp","./trees/tree-stage-5.webp","./trees/tree-stage-6.webp","./trees/tree-stage-7.webp"];
const absolute = (p) => new URL(p, self.registration.scope).href;
const allowed = new Set(ASSETS.map(absolute));
self.addEventListener("install", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      // Fetch a coherent, complete release. A failed download never replaces a working version.
      try {
        for (let i = 0; i < ASSETS.length; i += 8)
          await Promise.all(
            ASSETS.slice(i, i + 8).map(async (file) => {
              const req = new Request(absolute(file), { cache: "reload" }),
                response = await fetch(req);
              if (!response.ok)
                throw new Error("Offline asset missing: " + file);
              if (
                file.endsWith(".json") &&
                !response.headers.get("content-type")?.includes("json")
              )
                throw new Error("Invalid content: " + file);
              await cache.put(req, response);
            }),
          );
        await cache.put(absolute("./offline-ready"), new Response(BUILD));
      } catch (error) {
        await caches.delete(CACHE);
        throw error;
      }
      // An update waits. The UI activates it only on a deliberate user action.
    })(),
  ),
);
self.addEventListener("activate", (event) =>
  event.waitUntil(
    (async () => {
      const keys = await caches.keys(),
        ours = keys.filter((k) => k.startsWith(PREFIX));
      // Keep the previous release for already-open tabs. Never delete another application's cache.
      const old = ours.filter((k) => k !== CACHE);
      for (const key of old.slice(0, -1)) await caches.delete(key);
      await self.clients.claim();
    })(),
  ),
);
self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
  if (event.data?.type === "STATUS")
    event.waitUntil(
      caches
        .open(CACHE)
        .then((c) => c.match(absolute("./offline-ready")))
        .then((ready) =>
          event.ports[0]?.postMessage({ ready: !!ready, build: BUILD }),
        ),
    );
});
self.addEventListener("fetch", (event) => {
  const request = event.request,
    url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  // QA reports/downloads are standalone documents, not application navigation.
  // Serving the cached app shell here breaks reports for already-controlled browsers.
  if (url.pathname.startsWith(new URL("./qa/", self.registration.scope).pathname)) return;
  // Browser update checks for sw.js and unknown requests stay on the network.
  if (url.pathname.endsWith("/sw.js")) return;
  if (request.mode === "navigate") {
    event.respondWith(
      caches
        .open(CACHE)
        .then((c) => c.match(absolute("./index.html")))
        .then((r) => r || fetch(request)),
    );
    return;
  }
  if (!allowed.has(url.href) && !url.pathname.includes("/releases/")) return;
  event.respondWith(
    (async () => {
      const own = await caches.open(CACHE),
        cached = await own.match(request);
      if (cached) return cached;
      if (url.pathname.includes("/releases/")) {
        const keys = (await caches.keys()).filter((k) => k.startsWith(PREFIX));
        for (const key of keys) {
          const found = await (await caches.open(key)).match(request);
          if (found) return found;
        }
      }
      return fetch(request);
    })(),
  );
});
